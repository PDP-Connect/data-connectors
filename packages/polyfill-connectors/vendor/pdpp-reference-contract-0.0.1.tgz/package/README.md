# @pdpp/reference-contract (private stand-in)

Not the real `@pdpp/reference-contract` package (that stays in `PDP-Connect/pdpp` /
`PDP-Connect/data-connect` and is out of scope for this move). This exists only because
`@pdpp/collector-runtime`'s `src/local-device-client.ts` imports
`canonicalTerminalRunCommitEnvelope` from `@pdpp/reference-contract/common`, and because
`polyfill-connectors`' own restored conformance/coverage tests (Gate B finding B2) import
`evaluateStreamCoherence` and `collectionScopeFingerprint` from `@pdpp/reference-contract/evidence`
— npm needs something resolvable at those import paths for `polyfill-connectors` to
install/typecheck/run.

## What's checked in and its exact source

All modules below are byte-identical copies from
`PDP-Connect/pdpp@27f6eb6a6fae671a04835c145e869efa8d457c9f` (branch `manifest-reconciliation`,
the head of the reorganization stack at the time of this restoration) — the same repository the
original `common/index.ts` copy was pinned against (`7b46f9a0ee28fafb421018ff283a329e4623e44a`,
an ancestor of this commit; the two files are identical between those commits, reconfirmed by
diff before copying).

| Stand-in file | Source path | Source commit |
|---|---|---|
| `common/index.ts` | `packages/reference-contract/src/common/terminal-run-commit.ts` | `27f6eb6a6fae671a04835c145e869efa8d457c9f` |
| `evidence/coherence.ts` | `packages/reference-contract/src/evidence/coherence.ts` | `27f6eb6a6fae671a04835c145e869efa8d457c9f` |
| `evidence/collection-scope.ts` | `packages/reference-contract/src/evidence/collection-scope.ts` | `27f6eb6a6fae671a04835c145e869efa8d457c9f` |
| `evidence/index.ts` | hand-written barrel (see below) | n/a |

`common/index.ts` carries `canonicalTerminalRunCommitEnvelope`/`canonicalTerminalRunCommitJson`
— the one function `collector-runtime`'s non-test code actually calls — and nothing else from
the real package's much larger surface (route manifests, OpenAPI generation, validators).

`evidence/coherence.ts` and `evidence/collection-scope.ts` are each self-documented in the real
package as deliberately dependency-free leaves: `coherence.ts`'s own header states it "imports
nothing — not the reference implementation, not the server, not even sibling contract modules",
and `collection-scope.ts`'s states it "imports nothing, holds no module-level mutable state, and
reads no clock, filesystem, or network." Confirmed independently by grepping both files for
`^import` at the pinned commit (zero matches in either). This is what makes them safe to copy in
isolation: no transitive closure exists to chase.

`evidence/index.ts` is **not** a copy of the real package's `evidence/index.ts` barrel. The real
barrel also re-exports `named-collection-scope.ts` and `scope-narrowing-authority.ts`; neither is
imported by any restored test in this package, so they are deliberately left out rather than
speculatively vendored. If a future restored test needs either, trace its own leaf-ness the same
way before adding it here — `scope-narrowing-authority.ts` in particular imports
`collection-scope.ts`, so it is no longer a zero-dependency leaf on its own.

## Why a checked-in `.tgz`, not a git dependency

npm's git-dependency syntax has no equivalent of pnpm's `#commit&path:subdir`. Confirmed by
experiment (2026-08-17): a spec like
`github:PDP-Connect/data-connect#<sha>:packages/collector-runtime` does NOT select the
subdirectory. `npm-package-arg` treats anything after the first `:` in the fragment as an
unrelated, unrecognized key and silently drops it — including the commit SHA itself, since the
whole `<sha>:packages/collector-runtime` string fails to parse as a bare committish. The
observed result installing that exact spec: npm cloned the **whole `data-connect` repo root**
at its **current default-branch HEAD**, not the pinned commit and not the subdirectory. That is
a silent-wrong-version hazard, not just a missing convenience, so the git-dependency approach is
rejected outright rather than treated as a partial win.

## Packaging

- `pdpp-collector-runtime-0.0.1.tgz` / `pdpp-connector-protocol-0.0.1.tgz`: built with
  `npm run build` then packed with `npm pack` from a clean checkout of
  `PDP-Connect/data-connect@525fffa6f7756b785700219afcaaacc4492a0819`, workspace packages
  `packages/collector-runtime` and `packages/connector-protocol`.
- `pdpp-reference-contract-0.0.1.tgz`: this stand-in, packed with `npm pack` from the
  `reference-contract/` directory checked into this vendor tree (not from the real
  `pdpp-connect/pdpp` package — see the provenance table above).
- Because `@pdpp/collector-runtime`'s dependency declarations point at the public registry
  (`"*"`), not at these vendor files, `package.json`'s `overrides` field is what actually forces
  npm to substitute the local tarball for `@pdpp/reference-contract` wherever
  `@pdpp/collector-runtime` depends on it. `polyfill-connectors` also depends on the tarball
  directly (`dependencies["@pdpp/reference-contract"]`), since its own restored tests import
  `@pdpp/reference-contract/evidence` and `/common` directly — a plain nested `file:` dependency
  in `collector-runtime`'s own `package.json` isn't an option for the transitive case since that
  file lives inside the already-packed tarball we don't control.
- sha256 (informational, alongside npm's own tarball integrity hash recorded in
  `package-lock.json` once installed): see `vendor/SHA256SUMS`.

`package.json` references `@pdpp/reference-contract` directly via a `file:./vendor/<name>.tgz`
dependency (npm's supported local-tarball dependency form), and the transitive
`@pdpp/connector-protocol` / `@pdpp/reference-contract` pins for `@pdpp/collector-runtime` via
`overrides`.

## Removal trigger

This is transitional. Once `@pdpp/collector-runtime` and `@pdpp/connector-protocol` publish
(from `PDP-Connect/data-connect`, to whatever registry that repo settles on) **and** the real
`@pdpp/reference-contract` becomes consumable by this repo (its own move/publish), delete this
directory and switch `package.json` back to normal semver-range registry dependencies. Until
then, drift between these tarballs and the pinned commit is bounded only by re-running the pack
step by hand — there is no automated freshness check. A parity test against the canonical
package (per Gate B finding S5) is not yet in place; this stand-in remains a bridge, not an
independent contract implementation, and must not gain functionality beyond what the restored
tests above require.
