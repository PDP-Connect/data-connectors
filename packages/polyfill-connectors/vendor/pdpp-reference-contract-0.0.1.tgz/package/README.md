# @pdpp/reference-contract (private stand-in)

Not the real `@pdpp/reference-contract` package (that stays in `PDP-Connect/pdpp` /
`PDP-Connect/data-connect` and is out of scope for this move). This exists only because
`@pdpp/collector-runtime`'s `src/local-device-client.ts` imports
`canonicalTerminalRunCommitEnvelope` from `@pdpp/reference-contract/common`, and npm needs
something resolvable at that import path for `polyfill-connectors` to install/typecheck/run.

`common/index.ts` is a byte-identical copy of the real package's
`src/common/terminal-run-commit.ts` at commit `7b46f9a0ee28fafb421018ff283a329e4623e44a` (the
same pin used for `@pdpp/collector-runtime` and `@pdpp/connector-protocol`) — the one function
`collector-runtime`'s non-test code actually calls, and nothing else from the real package's much
larger surface (route manifests, OpenAPI generation, validators).

Delete this stand-in and depend on the real `@pdpp/reference-contract` directly once it is
available to this repo (its own move/publish, not part of Move A).
