// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

/**
 * Local collector runner.
 *
 * Generalizes the local device exporter pattern: pair with a provider via
 * device-scoped enrollment, advertise runtime capabilities, run a connector
 * through the existing connector runtime, and upload records/blobs/run-events
 * through the device-scoped ingest routes.
 *
 * Spec: openspec/changes/introduce-local-collector-runner
 *
 * Boundary: this is reference/control-plane behavior. The Resource Server
 * stays read/query-only. Collector enrollment, heartbeat, ingest, and
 * diagnostics flow through the device-exporter scoped routes already
 * declared in `reference-implementation/server/index.js`.
 *
 * Capability gate: every collector run starts with a placement decision
 * against the COLLECTOR_RUNTIME_CAPABILITIES profile. Connectors whose
 * required bindings are not advertised by the collector runtime fail
 * before spawn with a typed `RuntimeCapabilityMismatchError` — see
 * `runtime-capabilities.ts`.
 */

import { type ChildProcessWithoutNullStreams, spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdirSync, writeFileSync } from "node:fs";
import { delimiter, join } from "node:path";
import { createInterface } from "node:readline";
import type { EmittedMessage, StartMessage, StreamScope } from "@pdpp/connector-protocol";
import { buildAgentVersion } from "./collector-build-info.ts";
import {
  type EnrollmentExchangeResponse,
  type HeartbeatLastError,
  type HeartbeatOutboxDiagnostics,
  LocalDeviceClient,
  LocalDeviceHttpError,
  LocalDeviceReceiptValidationError,
  LocalDeviceRequestTimeoutError,
  type TerminalCollectionFact,
  type TerminalRunCommitRequest,
} from "./local-device-client.ts";
import {
  buildLocalDeviceIngestBatchRequest,
  buildLocalDeviceRecordEnvelope,
  hashCanonicalJson,
  type LocalDeviceRecordEnvelope,
} from "./local-device-envelope.ts";
import {
  buildLocalDeviceOutboxId,
  LocalDeviceOutbox,
  type LocalDeviceOutboxItem,
  type LocalDeviceOutboxSummary,
} from "./local-device-outbox.ts";
import type { LocalDeviceQueue, LocalDeviceQueueItem } from "./local-device-queue.ts";
import {
  assertPlacementOrThrow,
  COLLECTOR_RUNTIME_CAPABILITIES,
  type ConnectorPlacementInput,
  type RuntimeBindingName,
} from "./runtime-capabilities.ts";

/**
 * Build-derived agent version reported on every heartbeat this runner emits,
 * resolved once at module load. Populates `device_exporters.agent_version` so an
 * owner can see which collector build a host is running — and catch stale-build
 * drift — without inspecting `dist/` mtimes on the machine. A built artifact
 * reports its real revision; an unbuilt source/`tsx` run reports `…+source`.
 * Redaction-safe: a version string plus a short revision token, never a path or
 * secret. See `collector-build-info.ts`.
 */
const COLLECTOR_AGENT_VERSION = buildAgentVersion();

/**
 * Maximum stderr bytes retained from a connector child before the runner
 * truncates and notes the drop. Connector failures should surface in the
 * exit-code error message; large local backfills can otherwise emit
 * progress logs that would balloon the runner's heap before the child
 * exits. 256 KiB keeps a meaningful tail without becoming a memory risk.
 */
export const COLLECTOR_STDERR_MAX_BYTES = 256 * 1024;

const COLLECTOR_GAP_DETAILS_MAX_CHARS = 300;
const KEYED_SECRET_RE =
  /\b(authorization|bearer|token|password|passwd|cookie|secret|otp|api[_-]?key)\b\s*[:=]\s*["']?[^"',\s}]+/gi;
const OTP_RE = /\b\d{6}\b/g;
const LONG_OPAQUE_RE = /\b[A-Za-z0-9_-]{24,}\b/g;
const SCAN_BATCH_LIMIT_DETAIL_RE =
  /enqueued\s+\d+\s+batches\s+>=\s+(?:run batch limit|(?:maxEnqueuedBatchesPerRun|\[REDACTED\]))\s+(\d+)/;
const CONNECTOR_PROTOCOL_DEBUG_DIR_ENV = "PDPP_DEBUG_CONNECTOR_PROTOCOL_DIR";
/**
 * Matches the REDACTED, PERSISTED `last_error` text a dead-letter row was
 * already written with — the only place this regex may still be used. Once a
 * row is dead-lettered, `failOutboxItem`'s sanitized message string is all
 * that survives in SQLite; there is no structured status/code left to
 * inspect, so `requeueTransientLocalDeviceDeadLetters` (the next-run
 * self-heal path, driven by {@link LocalDeviceOutbox.requeueDeadLetters})
 * has no choice but to pattern-match the legacy persisted prose. A LIVE
 * failure (still holding its original `Error` instance) must classify via
 * {@link classifyLocalDeviceFailure} instead — see the note there for why
 * prose-matching a live error is the wrong layer.
 */
const TRANSIENT_LOCAL_DEVICE_DEAD_LETTER_CLASS_RE =
  /^(?:local device request failed: (?:408|429|5\d\d)(?:\b|$)|local device request timed out after\b|fetch failed\b|ECONN|ETIMEDOUT|EAI_AGAIN|ENOTFOUND)/i;

/**
 * Transport-level error codes that indicate the request never reached (or
 * never got a response from) the server — the same vocabulary
 * `describeThrownTransportError` (`http-retry.ts`) documents: Node's
 * `fetch` reports every connect/DNS/reset/timeout fault as a contentless
 * `TypeError: fetch failed` and puts the real fault on `.cause.code`.
 * Structured, not prose — matched against `.code`, never `.message`.
 */
const TRANSIENT_NETWORK_ERROR_CODES = new Set([
  "ECONNREFUSED",
  "ECONNRESET",
  "EAI_AGAIN",
  "ENOTFOUND",
  "ETIMEDOUT",
  "UND_ERR_CONNECT_TIMEOUT",
  "UND_ERR_HEADERS_TIMEOUT",
  "UND_ERR_BODY_TIMEOUT",
  "UND_ERR_SOCKET",
]);

/**
 * Classify a LIVE (still-thrown) local-device failure as explicit-transient
 * using structured fields only — never the error's message text.
 *
 * `failOutboxItem` previously ran `TRANSIENT_LOCAL_DEVICE_DEAD_LETTER_CLASS_RE`
 * against the same sanitized message it was about to persist. That is
 * brittle in both directions: (1) a connector or proxy that folds an
 * unrelated string containing "503" or "ETIMEDOUT" into an error message
 * would be misclassified as transient even though nothing structured says
 * so, and (2) `LocalDeviceHttpError` already carries a typed `status`
 * (`408`/`429`/`5xx`) and `LocalDeviceRequestTimeoutError` is its own typed
 * class — re-deriving that from prose throws away information the error
 * object already has. This function reads only typed fields:
 * `LocalDeviceHttpError.status`, `LocalDeviceRequestTimeoutError`'s type
 * itself, and a bounded walk of `.cause.code` for network-transport faults
 * (mirroring `describeThrownTransportError`'s walk). It does NOT match on
 * `error.message`/`error.code` string content and does NOT broaden to any
 * error type outside these three structured shapes — an unrecognized error
 * (including a network error whose `.cause` lacks a known `.code`) is
 * classified non-transient, so it still exhausts `maxAttempts` and
 * dead-letters rather than retrying forever.
 */
function classifyLocalDeviceFailure(error: unknown): boolean {
  if (error instanceof LocalDeviceHttpError) {
    return error.status === 408 || error.status === 429 || (error.status >= 500 && error.status < 600);
  }
  if (error instanceof LocalDeviceRequestTimeoutError) {
    return true;
  }
  let cause: unknown = error instanceof Error ? error.cause : null;
  for (let depth = 0; depth < 3 && cause instanceof Error; depth += 1) {
    const { code } = cause as Error & { code?: unknown };
    if (typeof code === "string" && TRANSIENT_NETWORK_ERROR_CODES.has(code)) {
      return true;
    }
    ({ cause } = cause);
  }
  return false;
}

/**
 * Default policy bounds for durable outbox drains. These are intentionally
 * conservative; callers may override via `CollectorRunConfig.outboxPolicy`.
 *
 * - `leaseMs`: how long a claimed row stays leased before
 *   `recoverExpiredLeases` reclaims it. Must exceed worst-case ingest RTT.
 * - `drainBatchSize`: rows claimed per drain iteration.
 * - `maxDrainIterations`: hard ceiling so a single runner invocation can
 *   never spin forever on a poisoned outbox; remaining work surfaces via
 *   heartbeat and the next invocation continues.
 * - `maxDrainDurationMs`: wall-clock budget for a single drain pass.
 *   When exceeded, the drain stops cleanly between iterations and the
 *   remaining ready rows surface via the next runner invocation. Combined
 *   with `maxDrainIterations` this prevents a poisoned-but-fast outbox
 *   from monopolizing a runner invocation.
 * - `retryBackoffMs`: bounded backoff base; per-attempt grows linearly.
 * - `maxAttempts`: after this many failed attempts, the row dead-letters
 *   so it stops occupying drain bandwidth. Does not apply to an error the
 *   server explicitly marked retryable (see `maxRetryAfterMs`) — those stay
 *   durably `ready`/backed-off instead of consuming this terminal budget,
 *   because the server already told the client authoritatively to retry.
 * - `maxRetryAfterMs`: ceiling on how long a single explicit-retryable
 *   failure (`device_ingest_retryable`/408/429/5xx/timeout — see
 *   `TRANSIENT_LOCAL_DEVICE_DEAD_LETTER_CLASS_RE`) is allowed to back off
 *   before the next attempt, honoring the server's `Retry-After` up to this
 *   bound. Keeps a large or malicious `Retry-After` from stalling the row
 *   past one drain's `maxDrainDurationMs` budget indefinitely.
 * - `maxQueueDepth`: ceiling on pending-or-retrying outbox depth per
 *   source instance. When pending work crosses this ceiling the runner
 *   skips spawning a new connector child and surfaces an honest
 *   `blocked` heartbeat instead of growing the backlog further. The
 *   already-pending work continues to drain on subsequent invocations.
 * - `maxEnqueuedBatchesPerRun`: first-backfill/scan safety valve. When a
 *   connector emits more durable record batches than this during one
 *   invocation, the runner stops the child, records a retryable
 *   policy-budget gap, drains already-queued work, and refuses to commit
 *   checkpoint state for the interrupted scan.
 */
export interface CollectorOutboxPolicy {
  drainBatchSize: number;
  leaseMs: number;
  maxAttempts: number;
  maxDrainDurationMs: number;
  maxDrainIterations: number;
  maxEnqueuedBatchesPerRun: number;
  maxQueueDepth: number;
  maxRetryAfterMs: number;
  retryBackoffMs: number;
}

export const DEFAULT_COLLECTOR_OUTBOX_POLICY: Readonly<CollectorOutboxPolicy> = Object.freeze({
  drainBatchSize: 4,
  leaseMs: 300_000,
  maxAttempts: 5,
  maxDrainDurationMs: 120_000,
  maxDrainIterations: 256,
  maxEnqueuedBatchesPerRun: 10_000,
  maxQueueDepth: 10_000,
  maxRetryAfterMs: 60_000,
  retryBackoffMs: 30_000,
});

/**
 * Run-time bound on retained acknowledged (`succeeded`) outbox rows.
 *
 * A `succeeded` row is an acknowledged outbox work item — a delivered record
 * batch, checkpoint, gap, or blob upload. Nothing reads it again: the server
 * already holds the durable copy, and the local row only survives as a
 * forensic tail. Without a bound it accumulates one row per acknowledged batch
 * forever, which is the root cause behind the 35 GB local outbox the
 * memory-pressure investigation found. The drain path is the natural place to
 * bound it: after a clean drain the outbox is at its quietest, and pruning only
 * `succeeded` rows can never race or drop undelivered work.
 *
 * The bound is **count only**: keep the most-recent `keepRecentCount`
 * `succeeded` rows per source instance and prune every older one, *regardless
 * of how recently it was acknowledged*. This is a true upper bound on retained
 * rows — the tail can never exceed `keepRecentCount` no matter how fast the
 * source emits. The v1 implementation ANDed a 30-day age floor with the count
 * cap, which silently defeated the cap for the exact incident shape it was
 * meant to fix: a 170k-row outbox whose `succeeded` rows were *all*
 * acknowledged within the last ~15 days has nothing older than 30 days, so the
 * ANDed age clause matched zero rows and the file never shrank. Count-only
 * makes the cap load-bearing on its first post-deploy run.
 *
 * This mirrors the manual `prune-sent` CLI, which already drops the age filter
 * when `--keep-count` is the operator's sole policy "so the count cap works
 * independently of row age" — the automatic path now uses that same count-only
 * mechanism.
 *
 * `keepRecentCount` (10,000) is the runner's own per-run / per-source bound:
 * {@link CollectorOutboxPolicy.maxEnqueuedBatchesPerRun} and
 * {@link CollectorOutboxPolicy.maxQueueDepth} are both `10_000`, so the retained
 * acknowledged tail is held to roughly one run's enqueue budget / one queue's
 * depth worth of rows — the amount of in-flight work the runner already permits
 * — rather than an arbitrary fraction of it. It caps retention more than an
 * order of magnitude below the ~170k-row incident while keeping ample recent
 * history for after-the-fact inspection.
 *
 * The automatic path never writes a backup file — it runs every drain and a
 * multi-GB backup every 15 minutes is exactly the disk pressure this bound is
 * meant to relieve. The manual CLI keeps its backup-before-`--apply` behavior
 * and its optional `--older-than-days` age window for one-shot operator
 * compaction; the run-time prune relies on the count bound and the same
 * single-transaction, `succeeded`-only delete.
 */
export interface CollectorAutoPrunePolicy {
  /** When false, the run-time prune is skipped entirely. */
  enabled: boolean;
  /**
   * Keep the most-recent N succeeded rows per source instance and prune every
   * older one regardless of age. This is the sole retained-row bound, so it is
   * a true upper limit on the acknowledged tail.
   */
  keepRecentCount: number;
}

export const DEFAULT_COLLECTOR_AUTO_PRUNE_POLICY: Readonly<CollectorAutoPrunePolicy> = Object.freeze({
  enabled: true,
  keepRecentCount: 10_000,
});

/**
 * Resolve the effective auto-prune policy from (in increasing precedence) the
 * built-in default, an explicit run-config override, and environment overrides.
 * Operators get a no-rebuild override path:
 *
 * - `PDPP_COLLECTOR_AUTO_PRUNE=0|false|off|no` disables the run-time prune.
 * - `PDPP_COLLECTOR_AUTO_PRUNE_KEEP_COUNT=<int>` overrides the count bound.
 *
 * Invalid or absent env values fall through to the lower-precedence value
 * rather than throwing, so a malformed override never breaks a collector run.
 */
export function resolveCollectorAutoPrunePolicy(
  override?: Partial<CollectorAutoPrunePolicy>,
  env: NodeJS.ProcessEnv = process.env
): CollectorAutoPrunePolicy {
  const policy: CollectorAutoPrunePolicy = {
    ...DEFAULT_COLLECTOR_AUTO_PRUNE_POLICY,
    ...(override ?? {}),
  };

  const enabledRaw = env.PDPP_COLLECTOR_AUTO_PRUNE;
  if (typeof enabledRaw === "string" && enabledRaw.trim() !== "") {
    policy.enabled = !DISABLED_ENV_VALUES.has(enabledRaw.trim().toLowerCase());
  }

  const keepCount = parseNonNegativeInt(env.PDPP_COLLECTOR_AUTO_PRUNE_KEEP_COUNT);
  if (keepCount !== null) {
    policy.keepRecentCount = keepCount;
  }

  return policy;
}

const DISABLED_ENV_VALUES = new Set(["0", "false", "off", "no"]);

function parseNonNegativeInt(raw: string | undefined): number | null {
  if (typeof raw !== "string" || raw.trim() === "") {
    return null;
  }
  const value = Number(raw.trim());
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}

/**
 * Run the bounded auto-prune for one source instance after a clean drain.
 *
 * Returns the prune outcome so the run result can surface it for diagnostics.
 * Supplies `keepCount` as the *sole* bound — never an `olderThanIso` age floor
 * — so the count cap is a true upper limit on retained rows regardless of how
 * recently they were acknowledged. `keepCount` is always present (never a
 * "prune all succeeded" call) and the prune is scoped to the source instance so
 * one connection never prunes another's retained tail. Only `succeeded` rows
 * are eligible inside {@link LocalDeviceOutbox.pruneSent}; the
 * ready/leased/retrying/dead-letter rows this run may have left behind are
 * structurally untouchable here.
 */
export function autoPruneSucceededOutbox(input: {
  outbox: Pick<LocalDeviceOutbox, "pruneSent">;
  policy: CollectorAutoPrunePolicy;
  sourceInstanceId: string;
}): CollectorAutoPruneResult {
  if (!input.policy.enabled) {
    return { enabled: false, matched: 0, pruned: 0 };
  }
  const result = input.outbox.pruneSent({
    dryRun: false,
    keepCount: input.policy.keepRecentCount,
    sourceInstanceId: input.sourceInstanceId,
  });
  return { enabled: true, matched: result.matched, pruned: result.pruned };
}

function requeueTransientLocalDeviceDeadLetters(input: {
  outbox: LocalDeviceOutbox;
  sourceInstanceId: string;
}): number {
  return input.outbox.requeueDeadLetters({
    errorClassPattern: TRANSIENT_LOCAL_DEVICE_DEAD_LETTER_CLASS_RE,
    sourceInstanceId: input.sourceInstanceId,
  }).requeued;
}

export interface CollectorAutoPruneResult {
  /** False when the policy disabled the run-time prune (no prune attempted). */
  enabled: boolean;
  /** Succeeded rows that matched the bounded prune predicate. */
  matched: number;
  /** Succeeded rows actually deleted this pass. */
  pruned: number;
}

/**
 * Run-time policy for reclaiming the outbox freelist with an in-place `VACUUM`.
 *
 * {@link autoPruneSucceededOutbox} DELETEs over-retention `succeeded` rows, but
 * with `auto_vacuum = NONE` the freed pages stay in the file forever as
 * freelist — this is why the memory-pressure investigation found a 35 GB local
 * outbox whose live rows were only ~2 GB (94% freelist). That bloated file is
 * not a leak in the node heap (the collector's anonymous RSS stays ~100 MB),
 * but every collector run pulls the outbox pages the kernel touches into the
 * service cgroup's *file* page cache, so a 35 GB file lets the cgroup's
 * reclaimable cache climb toward `MemoryHigh` and inflates the reported
 * `MemoryPeak`. Returning the freelist to the filesystem keeps the on-disk file
 * — and therefore the cache the cgroup can accumulate from outbox I/O — bounded.
 *
 * The auto-compact is deliberately rare and guarded by the caller
 * ({@link autoCompactOutboxIfBloated}):
 *
 * - It runs only when `reclaimableBytes >= minReclaimableBytes`, so a healthy
 *   small outbox never pays for a whole-file rebuild.
 * - It runs only on a quiet lane (no `ready`/`leased`/`dead_letter` work),
 *   mirroring the manual `compact` CLI's refuse-when-unsent guard. `VACUUM` is
 *   lossless — it copies every row, succeeded or not, so it can never drop
 *   unsent work — but holding it to a drained lane keeps it a quiet-state
 *   maintenance op rather than something racing a live drain.
 *
 * It changes no cursor, checkpoint, or record semantics: it only returns
 * already-deleted pages to the OS.
 */
export interface CollectorAutoCompactPolicy {
  /** When false, the run-time auto-compact is skipped entirely. */
  enabled: boolean;
  /**
   * Only rebuild when the outbox freelist is at least this many bytes. The
   * default is high enough that a healthy outbox never triggers a whole-file
   * `VACUUM`, but low enough to reclaim long before the file reaches the
   * tens-of-GB bloat the incident produced.
   */
  minReclaimableBytes: number;
}

export const DEFAULT_COLLECTOR_AUTO_COMPACT_POLICY: Readonly<CollectorAutoCompactPolicy> = Object.freeze({
  enabled: true,
  minReclaimableBytes: 512 * 1024 * 1024,
});

/**
 * Resolve the effective auto-compact policy from (in increasing precedence) the
 * built-in default, an explicit run-config override, and environment overrides.
 * Operators get a no-rebuild override path:
 *
 * - `PDPP_COLLECTOR_AUTO_COMPACT=0|false|off|no` disables the run-time compact.
 * - `PDPP_COLLECTOR_AUTO_COMPACT_MIN_RECLAIM_BYTES=<int>` overrides the byte
 *   threshold (use `0` to compact whenever any freelist exists).
 *
 * Invalid or absent env values fall through to the lower-precedence value
 * rather than throwing, so a malformed override never breaks a collector run.
 */
export function resolveCollectorAutoCompactPolicy(
  override?: Partial<CollectorAutoCompactPolicy>,
  env: NodeJS.ProcessEnv = process.env
): CollectorAutoCompactPolicy {
  const policy: CollectorAutoCompactPolicy = {
    ...DEFAULT_COLLECTOR_AUTO_COMPACT_POLICY,
    ...(override ?? {}),
  };

  const enabledRaw = env.PDPP_COLLECTOR_AUTO_COMPACT;
  if (typeof enabledRaw === "string" && enabledRaw.trim() !== "") {
    policy.enabled = !DISABLED_ENV_VALUES.has(enabledRaw.trim().toLowerCase());
  }

  const minBytes = parseNonNegativeInt(env.PDPP_COLLECTOR_AUTO_COMPACT_MIN_RECLAIM_BYTES);
  if (minBytes !== null) {
    policy.minReclaimableBytes = minBytes;
  }

  return policy;
}

/**
 * Reclaim the outbox freelist with an in-place `VACUUM` when the file is bloated
 * and the lane is quiet. No-op (and never opens a write transaction) unless all
 * guards pass, so the common healthy-run path pays only two cheap `PRAGMA`
 * reads.
 *
 * Guards, in order:
 *   1. Policy disabled → skipped.
 *   2. Reclaimable freelist below `minReclaimableBytes` → not worth a whole-file
 *      rebuild this run; the next over-threshold run reclaims it.
 *   3. Any non-`succeeded` row (`ready`/`leased`/`dead_letter`) present → defer
 *      so the rebuild stays a quiet-state op, matching the manual CLI guard.
 *
 * `VACUUM` is lossless and touches no cursor/checkpoint/record state, so the
 * only observable effect is a smaller on-disk file (and therefore less outbox
 * page cache charged to the service cgroup on later runs).
 */
export function autoCompactOutboxIfBloated(input: {
  outbox: Pick<LocalDeviceOutbox, "compact" | "countNonSucceeded" | "pageStats">;
  policy: CollectorAutoCompactPolicy;
}): CollectorAutoCompactResult {
  if (!input.policy.enabled) {
    return {
      compacted: false,
      enabled: false,
      reason: "disabled",
      reclaimedBytes: 0,
    };
  }
  const before = input.outbox.pageStats();
  if (before.reclaimableBytes < input.policy.minReclaimableBytes) {
    return {
      compacted: false,
      enabled: true,
      reason: "below_threshold",
      reclaimedBytes: 0,
    };
  }
  if (input.outbox.countNonSucceeded() > 0) {
    return {
      compacted: false,
      enabled: true,
      reason: "lane_not_quiet",
      reclaimedBytes: 0,
    };
  }
  const result = input.outbox.compact();
  return {
    compacted: true,
    enabled: true,
    reason: "compacted",
    reclaimedBytes: result.reclaimedBytes,
  };
}

export interface CollectorAutoCompactResult {
  /** True when a `VACUUM` rebuild actually ran this pass. */
  compacted: boolean;
  /** False when the policy disabled the run-time compact (no compact attempted). */
  enabled: boolean;
  /** Why the compact ran or was skipped. */
  reason: "disabled" | "below_threshold" | "lane_not_quiet" | "compacted";
  /** Bytes returned to the filesystem (0 unless `compacted`). */
  reclaimedBytes: number;
}

// Spawn `cwd`/PATH base for a connector child. This is deliberately the
// CALLER's process.cwd(), not a path derived from this module's own
// `import.meta.url`: `connector.args` (e.g. ["connectors/claude_code/index.ts"])
// is a path relative to wherever the connector content actually lives, and
// this generic runtime carries no knowledge of that location (moved out of
// `@pdpp/polyfill-connectors` in the engine-split; deriving from this file's
// own location would silently point at this package instead). Every real
// caller (the polyfill-connectors dev bin, its tests, the published
// `@pdpp/local-collector` bin) already runs with its cwd set to the
// connector-owning package root, matching pre-move behavior exactly.
const PACKAGE_ROOT = process.cwd();
const REPO_ROOT = join(PACKAGE_ROOT, "..", "..");

export interface CollectorEnrollmentConfig {
  baseUrl: string;
  code: string;
  /**
   * Narrowing-only scope request forwarded verbatim to the enroll route.
   * `undefined` sends no `collection_scope` field ("no preference"); an
   * explicit `null` requests a full pass. See `EnrollmentExchangeRequest`.
   */
  collectionScope?: { since?: string; source_roots?: string[] } | null;
  deviceLabel?: string;
}

export async function enrollCollector(config: CollectorEnrollmentConfig): Promise<EnrollmentExchangeResponse> {
  const client = new LocalDeviceClient({ baseUrl: config.baseUrl });
  return await client.exchangeEnrollment({
    ...(config.collectionScope === undefined ? {} : { collection_scope: config.collectionScope }),
    enrollment_code: config.code,
    ...(config.deviceLabel ? { deviceLabel: config.deviceLabel } : {}),
  });
}

/**
 * An owner-declared collection boundary, as the collector sees it.
 *
 * Structurally mirrors `@pdpp/reference-contract`'s `CollectionScope` (which
 * owns the normalization/fingerprint/proof-validity rules the RI and
 * conformance tooling share). It is restated here rather than imported because
 * the published collector bundle deliberately carries no dependency on the
 * reference contract — the same reason connectors restate other wire shapes.
 * The server is the authority for what a scope MEANS; the collector's job is to
 * receive it and stay inside it.
 */
export interface CollectionScope {
  readonly since?: string | null;
  readonly source_roots?: readonly string[] | null;
}

/**
 * Reserved `connector_state` key carrying the connection's owner-declared
 * boundary down to the collector on the existing state read.
 *
 * `$`-prefixed so it can never collide with a manifest stream name. It is NOT a
 * stream cursor and must be stripped before `START.state` is built, or the
 * connector would receive it as one.
 */
export const COLLECTION_SCOPE_STATE_KEY = "$collection_scope";

/**
 * Extract the server-declared boundary from the prior-state projection.
 *
 * The scope is delivered on the SAME read that already fetches stream cursors,
 * so a scoped run needs no extra round-trip and no new endpoint. A connection
 * that declared nothing yields `null` — an honest full pass.
 */
export function readCollectionScopeFromState(
  priorState: Readonly<Record<string, unknown>> | null | undefined
): CollectionScope | null {
  const entry = priorState?.[COLLECTION_SCOPE_STATE_KEY];
  if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
    return null;
  }
  const { scope } = entry as { scope?: unknown };
  if (typeof scope !== "object" || scope === null || Array.isArray(scope)) {
    return null;
  }
  const { since, source_roots } = scope as CollectionScope;
  return {
    ...(typeof since === "string" ? { since } : {}),
    ...(Array.isArray(source_roots) ? { source_roots: [...source_roots] } : {}),
  };
}

export interface CollectorConnectorSpec extends ConnectorPlacementInput {
  readonly args: readonly string[];
  /** Argv for the connector entrypoint (typically tsx + connector index.ts). */
  readonly command: string;
  /** Stable connector id used for ingest envelopes. */
  readonly connector_id: string;
  /**
   * Whether the connector declared it ENFORCES path roots at enumeration time.
   * Gates whether a roots boundary may be reported as `scoped` coverage; a
   * connector that has not implemented root pruning gets its roots scope
   * declassified rather than falsely claimed.
   */
  readonly enforcesSourceRoots?: boolean;
  /** Optional extra env passed to the connector child process. */
  readonly env?: NodeJS.ProcessEnv;
  /** Optional stream resources for scoped connector runs. */
  readonly resources?: Readonly<Record<string, readonly string[]>>;
  /**
   * The owner-declared collection boundary this run must stay inside, as
   * resolved from the durable per-connection scope. `null`/absent is a full
   * pass — itself a declared boundary, recorded as `unscoped` on the evidence.
   */
  readonly scope?: CollectionScope | null;
  /** Streams whose enumeration honors source roots. */
  readonly sourceRootScopableStreams?: readonly string[];
  /** Streams the collector should request from the connector. */
  readonly streams: readonly string[];
  /** Optional explicit stream backfills requested from the connector. */
  readonly streamsToBackfill?: readonly string[];
  /**
   * Streams the connector declared a `since` can be PROVEN against (mirrors the
   * manifest's `consent_time_field`; see `LocalCollectorDefinition`). Streams
   * outside this set remain in the requested inventory and are collected whole
   * under a scoped run rather than being narrowed against a field they do not
   * have.
   */
  readonly timeScopableStreams?: readonly string[];
}

export interface CollectorRunConfig {
  /**
   * Optional cooperative cancellation signal. When aborted, the runner
   * tears down the connector child process, stops draining the queue at
   * the next safe boundary, and surfaces an AbortError. Honored at the
   * pre-spawn capability gate, the prior-state read, child stdout
   * consumption, and between queue drain iterations.
   */
  abortSignal?: AbortSignal;
  /**
   * Override the run-time auto-compact (freelist `VACUUM`) of the durable
   * outbox. Defaults to {@link DEFAULT_COLLECTOR_AUTO_COMPACT_POLICY}; environment
   * overrides ({@link resolveCollectorAutoCompactPolicy}) take final precedence so
   * an operator can disable or retune it on a deployed host without a rebuild.
   */
  autoCompact?: Partial<CollectorAutoCompactPolicy>;
  /**
   * Override the run-time auto-prune of acknowledged (`succeeded`) outbox
   * rows. Defaults to {@link DEFAULT_COLLECTOR_AUTO_PRUNE_POLICY}; environment
   * overrides ({@link resolveCollectorAutoPrunePolicy}) take final precedence so
   * an operator can disable or retune it on a deployed host without a rebuild.
   */
  autoPrune?: Partial<CollectorAutoPrunePolicy>;
  baseUrl: string;
  batchSize?: number;
  /**
   * Stable identifier for the runner instance holding outbox leases. When
   * omitted, a fresh UUID is generated per invocation. Tests and host
   * supervisors that need predictable lease holders (e.g. for assertions
   * about which holder must acknowledge) can pin this.
   */
  collectorHolderId?: string;
  connector: CollectorConnectorSpec;
  deviceId: string;
  deviceToken: string;
  /**
   * Optional observer invoked for every protocol message the connector
   * child emits (RECORD, STATE, PROGRESS, DONE, etc.), in emission order,
   * before the message is applied to the durable outbox. Purely a
   * read-only tap for live progress reporting (e.g. the CLI's terminal
   * output) — it MUST NOT be relied on for correctness, is never awaited,
   * and any error it throws is swallowed so a reporting bug cannot break
   * the run.
   */
  onMessage?: (message: EmittedMessage) => void;
  /**
   * Path to the durable SQLite outbox. The legacy `queuePath` field is
   * accepted as a fallback when this is omitted so existing call sites
   * (CLI, tests) keep working as the implementation cuts over.
   */
  outboxPath?: string;
  /**
   * Override drain/retry bounds. Defaults to {@link DEFAULT_COLLECTOR_OUTBOX_POLICY}.
   */
  outboxPolicy?: Partial<CollectorOutboxPolicy>;
  queuePath: string;
  /**
   * Optional stable id for THIS run. When provided alongside `baseUrl`
   * and `deviceToken`, the connector subprocess gets PDPP_RUN_ID,
   * PDPP_REFERENCE_BASE_URL, and PDPP_LOCAL_DEVICE_TOKEN in its env so
   * the runtime can register the launched browser's CDP page-target
   * wsUrl with the reference server's run-target registry.
   *
   * Omit to disable streaming-target registration entirely (the
   * connector run is unaffected, but operator-side streaming will not
   * resolve a wsUrl for this run). Best-effort throughout: a missing
   * runId is the honest no-op mode.
   */
  runId?: string;
  sourceInstanceId: string;
}

/**
 * Coverage statuses emitted by the local source inventory's
 * `coverage_diagnostics` stream. Kept in sync with
 * `local-source-inventory.ts`'s `CoverageStatus`. `unaccounted` is not a
 * connector-emitted status today; it is reserved so a future inventory
 * that cannot classify a discovered store has a home in the summary
 * without changing this contract.
 */
export const COLLECTOR_COVERAGE_STATUSES = [
  "collected",
  "inventory_only",
  "excluded",
  "deferred",
  "missing",
  "unsupported",
  "unaccounted",
] as const;

export type CollectorCoverageStatus = (typeof COLLECTOR_COVERAGE_STATUSES)[number];

/**
 * Completeness summary derived from the `coverage_diagnostics` RECORDs a
 * connector emits during this run. This is deliberately distinct from
 * {@link CollectorRunResult.done}: `done.status` reports whether the
 * declared streams ran to a clean DONE, while this summary reports what
 * the local source inventory saw, collected, inventoried, excluded,
 * deferred, or could not account for. A run can succeed on every declared
 * stream while completeness shows excluded/deferred/missing stores — that
 * is the honest, non-failing local-completeness signal Section 5.2
 * requires.
 *
 * `null` on the run result means no coverage diagnostic was observed this
 * pass (the run did not request `coverage_diagnostics`, or the connector
 * did not spawn — e.g. a backlog skip). Absence is reported as absence,
 * not as "complete".
 *
 * The summary carries only the safe coverage fields — `store`, `stream`,
 * `status`. Each coverage RECORD's `data` is `{ id, store, stream, status,
 * reason }`; this summary keeps counts plus the per-store status map and
 * never copies `reason` text or any path/payload. The inventory itself
 * keeps `reason` free of paths and secrets.
 */
export interface CollectorCompletenessSummary {
  /** Per-store latest coverage status, keyed by store name. */
  byStore: Readonly<Record<string, CollectorCoverageStatus>>;
  /** Count of stores at each coverage status. */
  countsByStatus: Readonly<Record<CollectorCoverageStatus, number>>;
  /**
   * True when every discovered store reached an accounted status
   * (anything other than `unaccounted`). Declared-stream success does not
   * imply this; this is the completeness bit Section 5.2 separates out.
   */
  fullyAccounted: boolean;
  /** Total number of distinct stores the coverage diagnostic reported. */
  storeCount: number;
  /**
   * Stores whose coverage status is `unaccounted` — discovered but not
   * classified. Empty on a healthy run; non-empty means the connector saw
   * a store it could not place, which must not read as complete.
   */
  unaccountedStores: readonly string[];
}

export interface CollectorRunResult {
  /**
   * Transient local-device request dead letters requeued before the pre-scan
   * drain. Terminal dead letters stay dead-lettered and are not counted here.
   */
  autoRecoveredTransientDeadLetters: number;
  /**
   * Local-completeness summary from this run's `coverage_diagnostics`
   * RECORDs, distinct from {@link CollectorRunResult.done} (declared-stream
   * success). `null` when no coverage diagnostic was observed this pass.
   */
  completeness: CollectorCompletenessSummary | null;
  done: Extract<EmittedMessage, { type: "DONE" }> | null;
  enqueuedBatches: number;
  /**
   * Map of stream → cursor for STATE messages flushed to the server this pass.
   * Null when STATE was buffered but the flush was skipped because the
   * outbox still held undrained record work, or when no in-scope STATE
   * was emitted.
   */
  flushedState: Readonly<Record<string, unknown>> | null;
  /**
   * Outbox summary after this invocation's drain. Operators use it to
   * decide between rescheduling (pending/retrying > 0) and idle.
   */
  outboxSummary: LocalDeviceOutboxSummary;
  /** Prior state replayed into the START message (empty when first run). */
  priorState: Readonly<Record<string, unknown>>;
  /**
   * Outcome of this pass's run-time auto-prune of acknowledged (`succeeded`)
   * outbox rows. `enabled: false` means the prune was turned off; otherwise
   * `pruned` is how many over-retention succeeded rows this drain reclaimed.
   * Surfaced so operators and tests can see the bound working without
   * inspecting the SQLite file. Never reflects ready/leased/retrying/dead-letter
   * rows — those are not prune candidates.
   */
  prunedSent: CollectorAutoPruneResult;
  recordsQueued: number;
  /**
   * Number of leases recovered before scan/spawn. Non-zero means the
   * previous runner instance crashed mid-drain and left work claimed.
   */
  recoveredLeases: number;
  satisfiedBindings: readonly RuntimeBindingName[];
  /**
   * True when a spawned connector was stopped by the per-run scan enqueue
   * budget. Already-emitted records remain durable; checkpoint state is
   * intentionally not committed because the scan boundary is incomplete.
   */
  scanBudgetExceeded: boolean;
  sentBatches: number;
  /**
   * True when the runner skipped scanning a source for new work because
   * durable work was already pending/retrying/leased/dead-letter for the
   * source instance. The connector child does not spawn in this case.
   */
  skippedScanForBacklog: boolean;
  /** True when the runner failed to persist accumulated STATE after a successful drain. */
  statePutFailed: boolean;
  /**
   * Highest number of unflushed RECORDs the streaming buffer held at once.
   * Bounded by `batchSize`; exposed so memory-bounding behavior can be
   * asserted in tests without inspecting heap usage directly.
   */
  streamingBufferHighWaterMark: number;
}

export class CollectorStateReadError extends Error {
  constructor(message: string, cause: unknown) {
    super(message, { cause });
    this.name = "CollectorStateReadError";
  }
}

/**
 * Generalization of the codex local-device exporter loop.
 *
 * Pre-spawn: gates the connector against the collector runtime
 * capability profile. If a required binding is absent, throws
 * `RuntimeCapabilityMismatchError` before any child process or
 * heartbeat is created.
 *
 * Spawn: runs the connector entrypoint as a child process, feeding
 * START on stdin and parsing emitted protocol messages off stdout.
 *
 * Post-spawn: builds device-scoped envelopes, enqueues them in the
 * durable outbox, drains acknowledged work against the device-exporter
 * ingest endpoint, and heartbeats start/healthy.
 */
// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: ordered durable-run lifecycle; splitting it would hide checkpoint and heartbeat ordering.
export async function runCollectorConnector(config: CollectorRunConfig): Promise<CollectorRunResult> {
  throwIfAborted(config.abortSignal);
  const satisfiedBindings = assertPlacementOrThrow(config.connector, COLLECTOR_RUNTIME_CAPABILITIES);

  const policy: CollectorOutboxPolicy = {
    ...DEFAULT_COLLECTOR_OUTBOX_POLICY,
    ...(config.outboxPolicy ?? {}),
  };
  const autoPrunePolicy = resolveCollectorAutoPrunePolicy(config.autoPrune);
  const autoCompactPolicy = resolveCollectorAutoCompactPolicy(config.autoCompact);
  const holderId = config.collectorHolderId ?? randomUUID();
  const outboxPath = config.outboxPath ?? config.queuePath;
  const outbox = new LocalDeviceOutbox({ path: outboxPath });
  const client = new LocalDeviceClient({
    baseUrl: config.baseUrl,
    deviceId: config.deviceId,
    deviceToken: config.deviceToken,
  });

  // Tracks whether the pre-scan "starting" heartbeat has been sent. The
  // corrective heartbeat below only fires once it has, so a failure that
  // happens *before* "starting" (notably the state-read block, which emits its
  // own honest "blocked") keeps its deliberate status instead of being
  // overwritten by an outbox-derived one.
  let startingHeartbeatSent = false;
  // A failed state read emits the definitive terminal heartbeat for this pass.
  // Never replace it with a generic corrective status in the outer catch.
  let definitiveBlockedHeartbeatSent = false;
  // Distinguishes a failure while only draining/heartbeating old backlog from
  // a failure after a new local scan began. Only the latter invalidates the
  // scan's coverage proof with a new child-failure barrier.
  let scanStarted = false;
  try {
    const initialSummary = outbox.summary({
      sourceInstanceId: config.sourceInstanceId,
    });
    await client.heartbeat({
      agent_version: COLLECTOR_AGENT_VERSION,
      connector_id: config.connector.connector_id,
      outbox: buildHeartbeatOutboxDiagnostics(initialSummary, {
        backlogOpen: countOpenBacklogGaps(outbox, config.sourceInstanceId),
      }),
      records_pending: pendingOutboxWorkCount(initialSummary),
      source_instance_id: config.sourceInstanceId,
      status: "starting",
    });
    startingHeartbeatSent = true;

    const autoRecoveredTransientDeadLetters = requeueTransientLocalDeviceDeadLetters({
      outbox,
      sourceInstanceId: config.sourceInstanceId,
    });
    const recoveredLeases = outbox.recoverExpiredLeases({
      sourceInstanceId: config.sourceInstanceId,
    });
    const preScanDrain = await drainCollectorOutbox({
      ...(config.abortSignal ? { abortSignal: config.abortSignal } : {}),
      client,
      connectorId: config.connector.connector_id,
      holderId,
      outbox,
      policy,
      sourceInstanceId: config.sourceInstanceId,
    });

    const postDrainSummary = outbox.summary({
      sourceInstanceId: config.sourceInstanceId,
    });
    const skipResult = await maybeSkipScanForBacklog({
      autoPrunePolicy,
      autoRecoveredTransientDeadLetters,
      client,
      config,
      outbox,
      policy,
      postDrainSummary,
      preScanDrain,
      recoveredLeases,
      satisfiedBindings,
    });
    if (skipResult) {
      return skipResult;
    }

    const priorStateProjection = await readPriorStateOrBlock({
      client,
      config,
      onBlocked: () => {
        definitiveBlockedHeartbeatSent = true;
      },
      recordsPending: pendingOutboxWorkCount(postDrainSummary),
    });
    const priorState = priorStateProjection.state;

    await client.heartbeat({
      agent_version: COLLECTOR_AGENT_VERSION,
      connector_id: config.connector.connector_id,
      outbox: buildHeartbeatOutboxDiagnostics(postDrainSummary, {
        backlogOpen: countOpenBacklogGaps(outbox, config.sourceInstanceId),
      }),
      records_pending: pendingOutboxWorkCount(postDrainSummary),
      source_instance_id: config.sourceInstanceId,
      status: "starting",
    });
    startingHeartbeatSent = true;

    scanStarted = true;
    // The SERVER is the authority on the declared boundary: it is persisted with
    // the connection and delivered on the state read, so it cannot be widened by
    // a local flag or lost when the CLI process goes away. A caller-supplied
    // scope only applies when the connection declared none.
    const declaredScope = readCollectionScopeFromState(priorState) ?? config.connector.scope ?? null;
    const scopedConfig: CollectorRunConfig = {
      ...config,
      connector: { ...config.connector, scope: declaredScope },
    };
    const streamResult = await streamConnectorIntoOutbox({
      ...(config.abortSignal ? { abortSignal: config.abortSignal } : {}),
      batchSize: config.batchSize ?? 100,
      config: scopedConfig,
      outbox,
      policy,
      priorState,
    });
    const { done, bufferedState } = streamResult;
    const enqueueResult = {
      enqueuedBatches: streamResult.enqueuedBatches,
      recordsQueued: streamResult.recordsQueued,
    };

    const recordDrain = await drainCollectorOutbox({
      ...(config.abortSignal ? { abortSignal: config.abortSignal } : {}),
      client,
      connectorId: config.connector.connector_id,
      holderId,
      outbox,
      policy,
      sourceInstanceId: config.sourceInstanceId,
    });

    const afterRecordsSummary = outbox.summary({
      sourceInstanceId: config.sourceInstanceId,
    });
    const scopedTimeRanges = resolveScopedStreamTimeRanges(declaredScope, config.connector.timeScopableStreams);
    const scopedRoots = resolveScopedSourceRoots(declaredScope);
    const terminalFacts =
      done?.status === "succeeded" &&
      !streamResult.scanBudgetExceeded &&
      streamResult.coverageByStore &&
      Object.hasOwn(bufferedState, COVERAGE_DIAGNOSTICS_STREAM)
        ? buildTerminalCollectionFacts(
            streamResult.coverageByStore,
            scopedTimeRanges,
            scopedRoots,
            config.connector.enforcesSourceRoots === true,
            config.connector.sourceRootScopableStreams
          )
        : null;
    const checkpointResult = await maybeCommitCheckpoint({
      afterRecordsSummary,
      bufferedState,
      client,
      config,
      holderId,
      outbox,
      policy,
      terminalFacts,
      terminalRunBoundary: collectorScopeFingerprint(declaredScope),
      terminalRunConnectorInstanceId: priorStateProjection.connectorInstanceId,
    });

    await recoverResolvedLocalCollectorGaps({
      client,
      config,
      // A local failure barrier is recovered only by a complete successful
      // coverage STATE commit. A scoped success or corrective heartbeat is
      // deliberately insufficient.
      deferRecoveredGapCleanup:
        streamResult.scanBudgetExceeded ||
        done?.status !== "succeeded" ||
        !Object.hasOwn(checkpointResult.flushedState ?? {}, COVERAGE_DIAGNOSTICS_STREAM),
      outbox,
    });

    // Bound the retained acknowledged tail now that the drain has completed,
    // BEFORE reading the summary the heartbeat and run result report. Only
    // `succeeded` rows are eligible; the ready/leased/retrying/dead-letter work
    // this run may have left behind is structurally out of scope. Pruning first
    // means `finalSummary`, the heartbeat outbox diagnostics, and the returned
    // `outboxSummary` all reflect the post-prune `succeeded`/`total` counts —
    // the server never sees a stale pre-prune tail. (Pending/leased/dead-letter
    // counts and the heartbeat status are unaffected: the prune only ever
    // removes `succeeded` rows.)
    const prunedSent = autoPruneSucceededOutbox({
      outbox,
      policy: autoPrunePolicy,
      sourceInstanceId: config.sourceInstanceId,
    });

    // Reclaim the freelist the prune just left behind when the file is bloated
    // and the lane is quiet. Lossless rebuild: row counts are unchanged, so
    // `finalSummary` and the heartbeat below see the same outbox; only the
    // on-disk file (and the page cache later runs charge to the cgroup) shrinks.
    autoCompactOutboxIfBloated({ outbox, policy: autoCompactPolicy });

    const finalSummary = outbox.summary({
      sourceInstanceId: config.sourceInstanceId,
    });
    const recordsPending = pendingOutboxWorkCount(finalSummary);

    if (!checkpointResult.statePutFailed) {
      const finalDeadLetterError = buildHeartbeatDeadLetterError(outbox, config.sourceInstanceId);
      await client.heartbeat({
        agent_version: COLLECTOR_AGENT_VERSION,
        connector_id: config.connector.connector_id,
        ...(finalDeadLetterError ? { last_error: finalDeadLetterError } : {}),
        outbox: buildHeartbeatOutboxDiagnostics(finalSummary, {
          backlogOpen: countOpenBacklogGaps(outbox, config.sourceInstanceId),
        }),
        records_pending: recordsPending,
        source_instance_id: config.sourceInstanceId,
        status: streamResult.scanBudgetExceeded
          ? "retrying"
          : heartbeatStatusForSummary(finalSummary, policy, countOpenBacklogGaps(outbox, config.sourceInstanceId)),
      });
    }

    return {
      autoRecoveredTransientDeadLetters,
      completeness: summarizeCollectorCompleteness(streamResult.coverageByStore),
      done,
      enqueuedBatches: enqueueResult.enqueuedBatches,
      flushedState: checkpointResult.flushedState,
      outboxSummary: finalSummary,
      priorState,
      prunedSent,
      recordsQueued: enqueueResult.recordsQueued,
      recoveredLeases,
      satisfiedBindings,
      scanBudgetExceeded: streamResult.scanBudgetExceeded,
      sentBatches: (preScanDrain.sentByKind.record_batch ?? 0) + (recordDrain.sentByKind.record_batch ?? 0),
      skippedScanForBacklog: false,
      statePutFailed: checkpointResult.statePutFailed,
      streamingBufferHighWaterMark: streamResult.bufferHighWaterMark,
    };
  } catch (error) {
    // A throw after the "starting" heartbeat (connector child failure, unclean
    // exit, abort, protocol-parse error, drain transition error, …) would
    // otherwise leave "starting" as the last status the server ever saw — even
    // though the collector is healthily delivering: its already-queued work
    // drains on the *next* pass's pre-scan drain. Re-derive the status from the
    // durable outbox so the last heartbeat is honest. Skipped when "starting"
    // was never sent, preserving the honest "blocked" the state-read block
    // emits on its own.
    if (startingHeartbeatSent && !definitiveBlockedHeartbeatSent) {
      if (scanStarted) {
        ensureCollectorGapRow({
          clock: () => new Date(),
          connectorId: config.connector.connector_id,
          details: "collector run failed before a committed coverage checkpoint",
          outbox,
          reason: "connector_child_failure",
          retryable: true,
          ...(config.runId ? { runId: config.runId } : {}),
          sourceInstanceId: config.sourceInstanceId,
        });
      }
      await emitCorrectiveHeartbeatFromOutbox({
        client,
        config,
        outbox,
        policy,
      });
    }
    throw error;
  } finally {
    outbox.close();
  }
}

/**
 * Best-effort terminal heartbeat re-derived from the durable outbox after a
 * collector run threw past its final heartbeat. A drained source reports
 * "healthy", a source with pending work "retrying", and a dead-letter backlog
 * "blocked" — tying "healthy" to a concrete drain, never merely to the process
 * having booted. Emitted before the caller re-raises, so it never masks the
 * original failure.
 */
async function emitCorrectiveHeartbeatFromOutbox(input: {
  client: Pick<LocalDeviceClient, "heartbeat">;
  config: CollectorRunConfig;
  outbox: LocalDeviceOutbox;
  policy: CollectorOutboxPolicy;
}): Promise<void> {
  const summary = input.outbox.summary({
    sourceInstanceId: input.config.sourceInstanceId,
  });
  const deadLetterError = buildHeartbeatDeadLetterError(input.outbox, input.config.sourceInstanceId);
  await safeHeartbeat(input.client, {
    connector_id: input.config.connector.connector_id,
    ...(deadLetterError ? { last_error: deadLetterError } : {}),
    outbox: buildHeartbeatOutboxDiagnostics(summary, {
      backlogOpen: countOpenBacklogGaps(input.outbox, input.config.sourceInstanceId),
    }),
    records_pending: pendingOutboxWorkCount(summary),
    source_instance_id: input.config.sourceInstanceId,
    status: heartbeatStatusForSummary(
      summary,
      input.policy,
      countOpenBacklogGaps(input.outbox, input.config.sourceInstanceId)
    ),
  });
}

interface MaybeSkipScanInput {
  autoPrunePolicy: CollectorAutoPrunePolicy;
  autoRecoveredTransientDeadLetters: number;
  client: Pick<LocalDeviceClient, "heartbeat">;
  config: CollectorRunConfig;
  outbox: LocalDeviceOutbox;
  policy: CollectorOutboxPolicy;
  postDrainSummary: LocalDeviceOutboxSummary;
  preScanDrain: DrainCollectorOutboxResult;
  recoveredLeases: number;
  satisfiedBindings: readonly RuntimeBindingName[];
}

async function maybeSkipScanForBacklog(input: MaybeSkipScanInput): Promise<CollectorRunResult | null> {
  if (!hasScanBlockingOutboxWork(input.outbox, input.config.sourceInstanceId, input.policy)) {
    return null;
  }
  const recordsPending = pendingOutboxWorkCount(input.postDrainSummary);
  // When the skip is triggered by the configured queue-depth ceiling we
  // record a durable gap row so the deferred scan is visible as
  // first-class diagnostic evidence (not just an in-flight heartbeat).
  // Skips caused by pre-existing pending work that is still well under
  // the ceiling do not get a gap row: that pending work is already
  // represented by its own outbox rows.
  if (recordsPending >= input.policy.maxQueueDepth) {
    ensureCollectorGapRow({
      clock: () => new Date(),
      connectorId: input.config.connector.connector_id,
      details: `pending ${recordsPending} >= maxQueueDepth ${input.policy.maxQueueDepth}`,
      outbox: input.outbox,
      reason: "policy_budget",
      retryable: true,
      ...(input.config.runId ? { runId: input.config.runId } : {}),
      sourceInstanceId: input.config.sourceInstanceId,
    });
  }
  // The pre-scan drain has completed, so the bounded prune of acknowledged
  // rows is safe even though scan was skipped — and bounding the tail on a busy
  // lane that keeps skipping scans is exactly where it matters most. Prune
  // BEFORE reading the summary the heartbeat and run result report, so the
  // server sees the post-prune `succeeded` count rather than the stale tail.
  // Open backlog rows (ready/leased/retrying/dead-letter) are not prune
  // candidates, so the pending count and heartbeat status are unaffected.
  const prunedSent = autoPruneSucceededOutbox({
    outbox: input.outbox,
    policy: input.autoPrunePolicy,
    sourceInstanceId: input.config.sourceInstanceId,
  });
  const summaryAfterGap = input.outbox.summary({
    sourceInstanceId: input.config.sourceInstanceId,
  });
  const recordsPendingAfterGap = pendingOutboxWorkCount(summaryAfterGap);
  await input.client.heartbeat({
    agent_version: COLLECTOR_AGENT_VERSION,
    connector_id: input.config.connector.connector_id,
    outbox: buildHeartbeatOutboxDiagnostics(summaryAfterGap, {
      backlogOpen: countOpenBacklogGaps(input.outbox, input.config.sourceInstanceId),
    }),
    records_pending: recordsPendingAfterGap,
    source_instance_id: input.config.sourceInstanceId,
    status: heartbeatStatusForSummary(
      summaryAfterGap,
      input.policy,
      countOpenBacklogGaps(input.outbox, input.config.sourceInstanceId)
    ),
  });
  return {
    autoRecoveredTransientDeadLetters: input.autoRecoveredTransientDeadLetters,
    // No connector spawned on a backlog skip, so no coverage was observed.
    completeness: null,
    done: null,
    enqueuedBatches: 0,
    flushedState: null,
    outboxSummary: summaryAfterGap,
    priorState: Object.freeze({}),
    prunedSent,
    recordsQueued: 0,
    recoveredLeases: input.recoveredLeases,
    satisfiedBindings: input.satisfiedBindings,
    scanBudgetExceeded: false,
    sentBatches: input.preScanDrain.sentByKind.record_batch ?? 0,
    skippedScanForBacklog: true,
    statePutFailed: false,
    streamingBufferHighWaterMark: 0,
  };
}

async function readPriorStateOrBlock(input: {
  client: Pick<LocalDeviceClient, "getSourceInstanceState" | "heartbeat">;
  config: CollectorRunConfig;
  onBlocked?: () => void;
  recordsPending: number;
}): Promise<{
  connectorInstanceId: string;
  state: Readonly<Record<string, unknown>>;
}> {
  try {
    throwIfAborted(input.config.abortSignal);
    const projection = await input.client.getSourceInstanceState({
      sourceInstanceId: input.config.sourceInstanceId,
    });
    return {
      connectorInstanceId: projection.connector_instance_id,
      state:
        projection.state && typeof projection.state === "object"
          ? Object.freeze({ ...projection.state })
          : Object.freeze({}),
    };
  } catch (error) {
    await safeHeartbeat(input.client, {
      connector_id: input.config.connector.connector_id,
      // Discriminate the stall shape only — never the raw state-read error,
      // which may carry AS-reach detail. The dashboard now learns this is a
      // state-read block (cleared by re-running the collector), not a
      // dead-letter backlog, instead of an undifferentiated `blocked`.
      last_error: { kind: "state_read_failed" },
      records_pending: input.recordsPending,
      source_instance_id: input.config.sourceInstanceId,
      status: "blocked",
    });
    input.onBlocked?.();
    // biome-ignore lint/style/useErrorCause: CollectorStateReadError's constructor already forwards `error` into `super(message, { cause })`; biome does not recognize cause-threading through custom Error subclasses.
    throw new CollectorStateReadError(
      `failed to read prior state for ${input.config.sourceInstanceId}: ${error instanceof Error ? error.message : String(error)}`,
      error
    );
  }
}

interface StreamConnectorIntoOutboxInput {
  abortSignal?: AbortSignal;
  batchSize: number;
  config: CollectorRunConfig;
  outbox: LocalDeviceOutbox;
  policy: CollectorOutboxPolicy;
  priorState: Readonly<Record<string, unknown>>;
}

interface StreamConnectorIntoOutboxResult {
  bufferedState: Readonly<Record<string, unknown>>;
  bufferHighWaterMark: number;
  /**
   * Per-store coverage status accumulated from `coverage_diagnostics`
   * RECORDs seen this pass, or `null` when none were observed. Last write
   * wins per store so a re-emitted store keeps its final status.
   */
  coverageByStore: Map<string, { status: CollectorCoverageStatus; stream: string | null }> | null;
  done: Extract<EmittedMessage, { type: "DONE" }> | null;
  enqueuedBatches: number;
  recordsQueued: number;
  scanBudgetExceeded: boolean;
}

/**
 * Stream name on which the local source inventory emits coverage records.
 * Mirrors the connector-side stream contract; the runner only needs the
 * name to recognize and aggregate the diagnostic.
 */
const COVERAGE_DIAGNOSTICS_STREAM = "coverage_diagnostics";

/**
 * Extract the safe `{ store, status }` coverage entry from a
 * `coverage_diagnostics` RECORD, or `null` when the message is not a
 * coverage record or lacks a store. An unrecognized status maps to
 * `unaccounted` so a future tool release cannot read as complete.
 */
function coverageEntryFromRecord(message: Extract<EmittedMessage, { type: "RECORD" }>): {
  status: CollectorCoverageStatus;
  store: string;
  stream: string | null;
} | null {
  if (message.stream !== COVERAGE_DIAGNOSTICS_STREAM) {
    return null;
  }
  const { data } = message;
  const dataStore = isRecord(data) && typeof data.store === "string" && data.store ? data.store : null;
  const keyStore = typeof message.key === "string" && message.key ? message.key : null;
  const store = dataStore ?? keyStore;
  if (!store) {
    return null;
  }
  const rawStatus = isRecord(data) && typeof data.status === "string" ? data.status : null;
  if (!rawStatus) {
    return null;
  }
  const status = (COLLECTOR_COVERAGE_STATUSES as readonly string[]).includes(rawStatus)
    ? (rawStatus as CollectorCoverageStatus)
    : "unaccounted";
  return {
    status,
    store,
    stream: isRecord(data) && typeof data.stream === "string" && data.stream ? data.stream : null,
  };
}

/**
 * Fold the per-store coverage map collected during a run into the safe
 * {@link CollectorCompletenessSummary} surfaced on the run result. Returns
 * `null` when no coverage diagnostic was observed so absence reads as
 * absence rather than "complete".
 */
export function summarizeCollectorCompleteness(
  coverageByStore: Map<string, { status: CollectorCoverageStatus; stream: string | null }> | null
): CollectorCompletenessSummary | null {
  if (!coverageByStore || coverageByStore.size === 0) {
    return null;
  }
  const countsByStatus: Record<CollectorCoverageStatus, number> = Object.fromEntries(
    COLLECTOR_COVERAGE_STATUSES.map((status) => [status, 0])
  ) as Record<CollectorCoverageStatus, number>;
  const unaccountedStores: string[] = [];
  const byStore: Record<string, CollectorCoverageStatus> = {};
  for (const store of [...coverageByStore.keys()].sort()) {
    const status = coverageByStore.get(store)?.status as CollectorCoverageStatus;
    byStore[store] = status;
    countsByStatus[status] += 1;
    if (status === "unaccounted") {
      unaccountedStores.push(store);
    }
  }
  return {
    byStore,
    countsByStatus,
    fullyAccounted: unaccountedStores.length === 0,
    storeCount: coverageByStore.size,
    unaccountedStores,
  };
}

/**
 * Preserve the collector's existing per-store coverage diagnostics at the
 * terminal handoff. The server's manifest coverage-policy authority decides
 * whether an observed absence is accepted; the runner must not invent policy.
 */
export function buildTerminalCollectionFacts(
  coverageByStore: ReadonlyMap<string, { status: CollectorCoverageStatus; stream: string | null }>,
  timeRanges: CollectorStreamTimeRanges = {},
  sourceRoots: readonly string[] = [],
  enforcesSourceRoots = false,
  sourceRootScopableStreams: readonly string[] = []
): readonly TerminalCollectionFact[] {
  const statusesByStream = new Map<string, CollectorCoverageStatus[]>();
  for (const entry of coverageByStore.values()) {
    if (!entry.stream) {
      continue;
    }
    const statuses = statusesByStream.get(entry.stream) ?? [];
    statuses.push(entry.status);
    statusesByStream.set(entry.stream, statuses);
  }
  // Path roots bound enumeration for every stream — but ONLY when the connector
  // positively declared it enforces them. Supplying roots to a connector that
  // never implemented root pruning would otherwise mark every stream `scoped`
  // while the run walked the whole corpus: a fabricated watermark. For such a
  // connector the roots boundary is declassified here (data still collected, no
  // stream claims the bound) rather than silently honoured.
  const rootsBounded = sourceRoots.length > 0 && enforcesSourceRoots;
  const rootScopedStreams = new Set(sourceRootScopableStreams);
  const scopedRun = rootsBounded || Object.keys(timeRanges).length > 0;
  return [...statusesByStream.entries()]
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([stream, statuses]) => ({
      coverage_statuses: [...statuses].sort(),
      stream,
      // Only meaningful on a scoped run. `false` is the honest marker for a
      // stream the bound could not be enforced on: it was collected whole, so
      // its coverage must never be read as proving the declared boundary.
      ...(scopedRun
        ? {
            scoped: Object.hasOwn(timeRanges, stream) || (rootsBounded && rootScopedStreams.has(stream)),
          }
        : {}),
    }));
}

/**
 * Drive the connector child process and translate its protocol output
 * into durable outbox rows incrementally.
 *
 * Memory bounds:
 *
 * - At most `batchSize` RECORD messages are held in the streaming buffer
 *   at any time; the buffer flushes to a durable record_batch outbox row
 *   as soon as it fills.
 * - STATE messages are projected per-stream (last-wins) into a small
 *   in-memory map keyed by stream name. The map size is bounded by the
 *   connector's declared in-scope streams; out-of-scope STATE is dropped
 *   with the same stderr warning the buffered implementation used.
 * - DONE retains only the final `DONE` message (one reference).
 *
 * Failure semantics:
 *
 * - If the child exits non-zero (or stdout streaming fails), the function
 *   throws. Before throwing, any RECORD messages already parsed and
 *   accepted — including a partial trailing batch smaller than batchSize —
 *   are flushed into a durable record_batch row so the next runner
 *   invocation can drain them. STATE is intentionally NOT turned into a
 *   checkpoint outbox row here — the caller only enqueues a checkpoint
 *   after the record drain succeeds, so a mid-stream crash cannot
 *   advance the destination checkpoint past acknowledged work.
 */
// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: protocol transitions share one ordered durable-batch state machine.
async function streamConnectorIntoOutbox(
  input: StreamConnectorIntoOutboxInput
): Promise<StreamConnectorIntoOutboxResult> {
  throwIfAborted(input.abortSignal);

  const child = spawnConnector(input.config.connector, {
    baseUrl: input.config.baseUrl,
    deviceToken: input.config.deviceToken,
    ...(input.config.runId ? { runId: input.config.runId } : {}),
  });
  const stderr = new BoundedStderrBuffer(COLLECTOR_STDERR_MAX_BYTES);
  const inScopeStreams = new Set(input.config.connector.streams);
  const bufferedState: Record<string, unknown> = {};
  let batchSeq = nextOutboxBatchSeq(input.outbox, input.config.sourceInstanceId);
  let pendingRecords: Extract<EmittedMessage, { type: "RECORD" }>[] = [];
  let bufferHighWaterMark = 0;
  let recordsQueued = 0;
  let enqueuedBatches = 0;
  let done: Extract<EmittedMessage, { type: "DONE" }> | null = null;
  let scanBudgetExceeded = false;
  // Accumulate coverage diagnostics as we see them so completeness can be
  // summarized without re-reading the durable outbox. Stays null until the
  // first coverage record so an absent diagnostic reads as absent.
  let coverageByStore: Map<string, { status: CollectorCoverageStatus; stream: string | null }> | null = null;

  const flushPendingBatch = (): void => {
    if (pendingRecords.length === 0) {
      return;
    }
    const chunk = pendingRecords;
    pendingRecords = [];
    const batchId = buildOutboxBatchId({
      batchSeq,
      connectorId: input.config.connector.connector_id,
      records: chunk,
      sourceInstanceId: input.config.sourceInstanceId,
    });
    const envelopes = chunk.map((record) =>
      buildLocalDeviceRecordEnvelope({
        batchId,
        batchSeq,
        connectorId: input.config.connector.connector_id,
        deviceId: input.config.deviceId,
        record,
        sourceInstanceId: input.config.sourceInstanceId,
      })
    );
    input.outbox.enqueue({
      id: buildLocalDeviceOutboxId({
        kind: "record_batch",
        parts: [input.config.connector.connector_id, batchSeq, batchId],
        sourceInstanceId: input.config.sourceInstanceId,
      }),
      kind: "record_batch",
      payload: {
        batchId,
        batchSeq,
        connectorId: input.config.connector.connector_id,
        deviceId: input.config.deviceId,
        records: envelopes,
        sourceInstanceId: input.config.sourceInstanceId,
      } satisfies RecordBatchPayload,
      sourceInstanceId: input.config.sourceInstanceId,
    });
    recordsQueued += envelopes.length;
    enqueuedBatches += 1;
    batchSeq += 1;
    scanBudgetExceeded = maybeRecordScanBudgetGap({
      enqueuedBatches,
      input,
      scanBudgetExceeded,
    });
  };

  const recordCoverageIfPresent = (message: Extract<EmittedMessage, { type: "RECORD" }>): void => {
    const entry = coverageEntryFromRecord(message);
    if (!entry) {
      return;
    }
    coverageByStore ??= new Map<string, { status: CollectorCoverageStatus; stream: string | null }>();
    coverageByStore.set(entry.store, {
      status: entry.status,
      stream: entry.stream,
    });
  };

  const notifyOnMessage = (message: EmittedMessage): void => {
    if (!input.config.onMessage) {
      return;
    }
    try {
      input.config.onMessage(message);
    } catch {
      // The observer is a read-only reporting tap (e.g. CLI progress
      // output); a bug in it must never break the run.
    }
  };

  const handleMessage = (message: EmittedMessage): void => {
    notifyOnMessage(message);
    if (done !== null) {
      throw new Error(`${input.config.connector.connector_id} emitted ${message.type} after terminal DONE`);
    }
    if (message.type === "RECORD") {
      recordCoverageIfPresent(message);
      pendingRecords.push(message);
      if (pendingRecords.length > bufferHighWaterMark) {
        bufferHighWaterMark = pendingRecords.length;
      }
      if (pendingRecords.length >= input.batchSize) {
        flushPendingBatch();
      }
      return;
    }
    if (message.type === "STATE") {
      if (!inScopeStreams.has(message.stream)) {
        process.stderr.write(
          `${input.config.connector.connector_id} dropped out-of-scope STATE for stream '${message.stream}'\n`
        );
        return;
      }
      bufferedState[message.stream] = message.cursor;
      return;
    }
    if (message.type === "DONE") {
      done = message;
    }
  };

  const abortListener = input.abortSignal
    ? () => {
        try {
          child.kill("SIGTERM");
        } catch {
          // ignore — child already exited
        }
        setTimeout(() => {
          try {
            if (!child.killed) {
              child.kill("SIGKILL");
            }
          } catch {
            // ignore
          }
        }, 1000).unref?.();
      }
    : null;
  if (input.abortSignal && abortListener) {
    input.abortSignal.addEventListener("abort", abortListener, { once: true });
  }

  const exitPromise = new Promise<number | null>((resolve, reject) => {
    child.once("error", reject);
    child.once("close", resolve);
  });
  const outputPromise = (async () => {
    const lines = createInterface({ input: child.stdout, terminal: false });
    let lineNumber = 0;
    for await (const line of lines) {
      lineNumber += 1;
      if (!line.trim()) {
        continue;
      }
      handleMessage(parseConnectorProtocolLine(line, lineNumber, input.config.connector.connector_id));
      if (scanBudgetExceeded) {
        try {
          child.kill("SIGTERM");
        } catch {
          // ignore — child already exited
        }
        break;
      }
    }
  })();
  child.stdin.on("error", () => {
    // Missing commands or early child exits can close stdin before the
    // START line is accepted. The child error/exit path below is the
    // actionable diagnostic; do not mask it with EPIPE.
  });
  child.stderr.on("data", (chunk: Buffer) => stderr.push(chunk));
  child.stdin.end(
    `${JSON.stringify(
      buildCollectorStartMessage(
        input.config.connector.streams,
        input.config.connector.streamsToBackfill,
        input.priorState,
        input.config.connector.resources,
        resolveScopedStreamTimeRanges(input.config.connector.scope, input.config.connector.timeScopableStreams),
        // Roots only reach the connector when it declared it enforces them, so
        // an unsupported connector cannot silently receive a boundary it will
        // ignore while the run still looks bounded.
        input.config.connector.enforcesSourceRoots === true
          ? resolveScopedSourceRoots(input.config.connector.scope)
          : []
      )
    )}\n`
  );

  let exitCode: number | null;
  try {
    [exitCode] = await Promise.all([exitPromise, outputPromise]);
  } catch (error) {
    if (input.abortSignal && abortListener) {
      input.abortSignal.removeEventListener("abort", abortListener);
    }
    // Records already parsed and accepted before the failure must reach the
    // durable outbox; the next runner pass will drain them. State stays
    // buffered-only so the checkpoint cannot advance past acknowledged work.
    flushPendingBatch();
    const details = sanitizeCollectorGapDetails(error instanceof Error ? error.message : String(error));
    recordConnectorChildFailureGap({
      details,
      enqueuedBatches,
      input,
    });
    throw new Error(
      `${input.config.connector.connector_id} connector failed to start or stream output: ${details || "unknown error"}`,
      { cause: error }
    );
  }
  if (input.abortSignal && abortListener) {
    input.abortSignal.removeEventListener("abort", abortListener);
  }
  if (input.abortSignal?.aborted) {
    flushPendingBatch();
    throw input.abortSignal.reason instanceof Error
      ? input.abortSignal.reason
      : new DOMException("Aborted", "AbortError");
  }
  // `done` is assigned by the nested protocol callback; TypeScript's local
  // flow analysis cannot observe that closure write, so retain its declared
  // protocol union at this boundary.
  const terminalDone = done as Extract<EmittedMessage, { type: "DONE" }> | null;
  throwIfConnectorExitedUncleanly({
    enqueuedBatches,
    exitCode,
    flushPendingBatch,
    input,
    scanBudgetExceeded,
    stderr,
    terminalDone,
  });

  // A zero exit only proves that the process stopped cleanly. It does not
  // prove that the requested inventory completed. Do not let a pre-DONE STATE
  // become a server checkpoint unless the connector explicitly terminally
  // succeeded; failed or missing DONE keeps the prior proof invalidated by a
  // durable recovery gap.
  if (!scanBudgetExceeded && terminalDone?.status !== "succeeded") {
    flushPendingBatch();
    const details = terminalDone
      ? `terminal DONE reported ${terminalDone.status}`
      : "connector exited without terminal DONE";
    recordConnectorChildFailureGap({ details, enqueuedBatches, input });
    throw new Error(`${input.config.connector.connector_id} ${details}`);
  }

  flushPendingBatch();

  return {
    bufferedState: Object.freeze(scanBudgetExceeded ? {} : { ...bufferedState }),
    bufferHighWaterMark,
    // Coverage is a diagnostic of what the inventory saw, not record-level
    // checkpoint state, so it is reported even when the scan budget cut the
    // run short — an honest partial coverage beats none.
    coverageByStore,
    done: scanBudgetExceeded ? null : done,
    enqueuedBatches,
    recordsQueued,
    scanBudgetExceeded,
  };
}

function parseConnectorProtocolLine(line: string, lineNumber: number, connectorId: string): EmittedMessage {
  try {
    return JSON.parse(line) as EmittedMessage;
  } catch (error) {
    const debugPath = writeConnectorProtocolDebugLine({
      connectorId,
      error,
      line,
      lineNumber,
    });
    const suffix = debugPath ? `; raw line saved to ${debugPath}` : "";
    throw new Error(
      `${error instanceof Error ? error.message : String(error)} at connector protocol line ${lineNumber} (${line.length} chars)${suffix}`,
      { cause: error }
    );
  }
}

function writeConnectorProtocolDebugLine(input: {
  connectorId: string;
  error: unknown;
  line: string;
  lineNumber: number;
}): string | null {
  const dir = process.env[CONNECTOR_PROTOCOL_DEBUG_DIR_ENV]?.trim();
  if (!dir) {
    return null;
  }
  try {
    mkdirSync(dir, { mode: 0o700, recursive: true });
    const path = join(dir, `${input.connectorId}-${Date.now()}-${randomUUID()}.json`);
    writeFileSync(
      path,
      `${JSON.stringify(
        {
          connector_id: input.connectorId,
          error: input.error instanceof Error ? input.error.message : String(input.error),
          line: input.line,
          line_length: input.line.length,
          line_number: input.lineNumber,
        },
        null,
        2
      )}\n`,
      { mode: 0o600 }
    );
    return path;
  } catch {
    return null;
  }
}

function throwIfConnectorExitedUncleanly(input: {
  enqueuedBatches: number;
  exitCode: number | null;
  flushPendingBatch: () => void;
  input: StreamConnectorIntoOutboxInput;
  scanBudgetExceeded: boolean;
  stderr: BoundedStderrBuffer;
  terminalDone: Extract<EmittedMessage, { type: "DONE" }> | null;
}): void {
  if (input.exitCode === 0 || input.scanBudgetExceeded) {
    return;
  }
  input.flushPendingBatch();
  // The connector protocol lets a child report its own failure reason via a
  // terminal DONE{status:"failed", error:{message}} on stdout before it
  // exits non-zero. That message is the connector's own diagnosis (e.g. a
  // missing source directory) and is far more useful than an empty stderr
  // buffer — prefer it when present instead of the generic exit-code/stderr
  // fallback, which previously discarded it unconditionally.
  const doneMessage = input.terminalDone?.status === "failed" ? input.terminalDone.error?.message : undefined;
  const details = sanitizeCollectorGapDetails(
    doneMessage ? doneMessage : `exit ${input.exitCode}: ${input.stderr.toString().trim()}`
  );
  recordConnectorChildFailureGap({
    details,
    enqueuedBatches: input.enqueuedBatches,
    input: input.input,
  });
  throw new Error(
    `${input.input.config.connector.connector_id} connector exited ${input.exitCode}: ${details || "unknown error"}`
  );
}

function maybeRecordScanBudgetGap(input: {
  enqueuedBatches: number;
  input: StreamConnectorIntoOutboxInput;
  scanBudgetExceeded: boolean;
}): boolean {
  if (input.scanBudgetExceeded) {
    return true;
  }
  if (input.enqueuedBatches < input.input.policy.maxEnqueuedBatchesPerRun) {
    return false;
  }
  ensureCollectorGapRow({
    clock: () => new Date(),
    connectorId: input.input.config.connector.connector_id,
    details: `enqueued ${input.enqueuedBatches} batches >= run batch limit ${input.input.policy.maxEnqueuedBatchesPerRun}`,
    outbox: input.input.outbox,
    reason: "policy_budget",
    retryable: true,
    ...(input.input.config.runId ? { runId: input.input.config.runId } : {}),
    sourceInstanceId: input.input.config.sourceInstanceId,
  });
  return true;
}

/**
 * Persist a `connector_child_failure` gap row when the connector child
 * crashes. Even a zero-record crash invalidates the prior coverage proof:
 * a full local inventory was attempted but did not terminally commit.
 */
function recordConnectorChildFailureGap(input: {
  details: string;
  enqueuedBatches: number;
  input: StreamConnectorIntoOutboxInput;
}): void {
  ensureCollectorGapRow({
    clock: () => new Date(),
    connectorId: input.input.config.connector.connector_id,
    details: input.details,
    outbox: input.input.outbox,
    reason: "connector_child_failure",
    retryable: true,
    ...(input.input.config.runId ? { runId: input.input.config.runId } : {}),
    sourceInstanceId: input.input.config.sourceInstanceId,
  });
}

async function maybeCommitCheckpoint(input: {
  afterRecordsSummary: LocalDeviceOutboxSummary;
  bufferedState: Readonly<Record<string, unknown>>;
  client: Pick<
    LocalDeviceClient,
    "ackLocalCollectorGap" | "commitTerminalRun" | "heartbeat" | "ingestBatch" | "putSourceInstanceState"
  >;
  config: CollectorRunConfig;
  holderId: string;
  outbox: LocalDeviceOutbox;
  policy: CollectorOutboxPolicy;
  terminalFacts: readonly TerminalCollectionFact[] | null;
  terminalRunBoundary: string;
  terminalRunConnectorInstanceId: string;
}): Promise<{
  flushedState: Readonly<Record<string, unknown>> | null;
  statePutFailed: boolean;
}> {
  if (Object.keys(input.bufferedState).length === 0 && !input.terminalFacts) {
    return { flushedState: null, statePutFailed: false };
  }

  const runId = input.config.runId ?? randomUUID();
  const terminalCommitIdentity = input.terminalFacts
    ? {
        collection_boundary: input.terminalRunBoundary,
        connector_id: input.config.connector.connector_id,
        connector_instance_id: input.terminalRunConnectorInstanceId,
        device_id: input.config.deviceId,
        run_id: runId,
        source_instance_id: input.config.sourceInstanceId,
        state_delta: input.bufferedState,
        terminal_facts: input.terminalFacts,
        version: 1 as const,
      }
    : null;
  const commitId = terminalCommitIdentity ? `terminal-commit:${hashCanonicalJson(terminalCommitIdentity)}` : null;
  const kind = terminalCommitIdentity ? "terminal_run_commit" : "checkpoint";
  const checkpointId = buildLocalDeviceOutboxId({
    kind,
    parts: terminalCommitIdentity ? [commitId] : [input.config.connector.connector_id, input.bufferedState],
    sourceInstanceId: input.config.sourceInstanceId,
  });
  input.outbox.enqueue({
    id: checkpointId,
    kind,
    payload: terminalCommitIdentity
      ? ({
          ...terminalCommitIdentity,
          commit_id: commitId as string,
        } satisfies TerminalRunCommitPayload)
      : ({
          connectorId: input.config.connector.connector_id,
          sourceInstanceId: input.config.sourceInstanceId,
          state: input.bufferedState,
        } satisfies CheckpointPayload),
    sourceInstanceId: input.config.sourceInstanceId,
  });

  const checkpointDrain = await drainCollectorOutbox({
    ...(input.config.abortSignal ? { abortSignal: input.config.abortSignal } : {}),
    client: input.client,
    connectorId: input.config.connector.connector_id,
    holderId: input.holderId,
    outbox: input.outbox,
    policy: input.policy,
    sourceInstanceId: input.config.sourceInstanceId,
  });
  const checkpointAfter = input.outbox.get(checkpointId);
  if (checkpointAfter?.status === "succeeded") {
    return {
      flushedState: Object.freeze({ ...input.bufferedState }),
      statePutFailed: false,
    };
  }
  if (checkpointAfter && hasCheckpointPredecessorBlockingWork(input.outbox, checkpointAfter)) {
    return { flushedState: null, statePutFailed: false };
  }

  const afterCommitSummary = input.outbox.summary({
    sourceInstanceId: input.config.sourceInstanceId,
  });
  await safeHeartbeat(input.client, {
    connector_id: input.config.connector.connector_id,
    ...(kind === "terminal_run_commit" ? { last_error: { kind: "terminal_run_commit_unacknowledged" as const } } : {}),
    outbox: buildHeartbeatOutboxDiagnostics(afterCommitSummary, {
      backlogOpen: countOpenBacklogGaps(input.outbox, input.config.sourceInstanceId),
    }),
    records_pending: pendingOutboxWorkCount(afterCommitSummary),
    source_instance_id: input.config.sourceInstanceId,
    status: "retrying",
  });
  process.stderr.write(
    `${input.config.connector.connector_id} ${kind} not yet committed (drained ${checkpointDrain.sent} this pass; ${checkpointAfter?.last_error ?? "no error"})\n`
  );
  return { flushedState: null, statePutFailed: true };
}

async function recoverResolvedLocalCollectorGaps(input: {
  client: Pick<LocalDeviceClient, "recoverLocalCollectorGap">;
  config: CollectorRunConfig;
  deferRecoveredGapCleanup?: boolean;
  outbox: LocalDeviceOutbox;
}): Promise<void> {
  if (input.deferRecoveredGapCleanup) {
    return;
  }
  if (hasCheckpointBlockingOutboxWork(input.outbox, input.config.sourceInstanceId)) {
    return;
  }
  const succeededGaps = input.outbox.listByKind({
    kind: "gap",
    sourceInstanceId: input.config.sourceInstanceId,
    statuses: ["succeeded"],
  });
  for (const item of succeededGaps) {
    let payload: GapPayload;
    try {
      payload = assertGapPayload(item.payload, item.id);
    } catch (error) {
      process.stderr.write(
        `${input.config.connector.connector_id} skipped malformed succeeded gap recovery ${item.id}: ${
          error instanceof Error ? error.message : String(error)
        }\n`
      );
      continue;
    }
    try {
      await input.client.recoverLocalCollectorGap({
        connector_id: payload.connectorId,
        reason: payload.reason,
        source_instance_id: payload.sourceInstanceId,
        ...(input.config.runId ? { recovered_run_id: input.config.runId } : {}),
        ...(payload.stream ? { stream: payload.stream } : {}),
        ...(payload.streamBoundary ? { stream_boundary: payload.streamBoundary } : {}),
      });
      input.outbox.deleteSucceeded(item.id);
    } catch (error) {
      process.stderr.write(
        `${input.config.connector.connector_id} local gap recovery deferred for ${item.id}: ${
          error instanceof Error ? error.message : String(error)
        }\n`
      );
    }
  }
}

async function safeHeartbeat(
  client: Pick<LocalDeviceClient, "heartbeat">,
  request: Parameters<LocalDeviceClient["heartbeat"]>[0]
): Promise<void> {
  try {
    // Stamp the build-derived agent version on every best-effort heartbeat too
    // (corrective post-throw, skip-for-backlog, state-read block), so a host
    // that only ever reports via these paths still surfaces its build. An
    // explicitly-provided value is preserved.
    await client.heartbeat({
      agent_version: COLLECTOR_AGENT_VERSION,
      ...request,
    });
  } catch {
    // Heartbeat is best-effort here; the caller is already handling a more
    // important failure and we do not want to mask it with a heartbeat error.
  }
}

/**
 * Per-stream time bounds for a scoped run, keyed by stream name.
 *
 * The runner does not decide which streams a bound applies to — that is the
 * connector's declared `time_scopable_streams`, mirrored from its manifest's
 * `consent_time_field`. The runner's job is transport: put the declared bound
 * on exactly those streams, so the connector runtime's existing generic
 * emission gate (`connector-runtime.ts`) enforces it without any connector
 * knowledge here.
 */
export type CollectorStreamTimeRanges = Readonly<Record<string, { readonly since: string }>>;

/**
 * Stable identity for a declared boundary, stamped onto terminal evidence.
 *
 * MUST stay byte-identical to `@pdpp/reference-contract`'s
 * `collectionScopeFingerprint` — the server compares the two to decide whether
 * stored proof still describes the currently-declared scope, so any drift would
 * silently invalidate valid proof (or, worse, validate stale proof). A
 * cross-implementation test pins them together.
 *
 * `unscoped` is a real value: a full pass is a declared boundary too, so
 * introducing a bound over one is detectable as a change.
 */
export function collectorScopeFingerprint(scope: CollectionScope | null | undefined): string {
  const since = typeof scope?.since === "string" ? scope.since.trim() : "";
  const validSince = since && !Number.isNaN(Date.parse(since)) ? since : "";
  const roots = Array.isArray(scope?.source_roots)
    ? [
        ...new Set(scope.source_roots.filter((root) => typeof root === "string" && root.trim()).map((r) => r.trim())),
      ].sort()
    : [];
  const parts: string[] = [];
  if (validSince) {
    parts.push(`since=${validSince}`);
  }
  if (roots.length > 0) {
    parts.push(`roots=${roots.join(",")}`);
  }
  return parts.length > 0 ? parts.join(";") : "unscoped";
}

/**
 * Resolve an owner-declared boundary into the per-stream bounds a START may
 * carry, given what the connector declared it can prove a bound against.
 *
 * The asymmetry is the honesty rule, not an oversight: a `since` lands ONLY on
 * streams in `timeScopableStreams`. Putting one on a stream with no time field
 * would hand the runtime's emission gate a field the record does not have — the
 * bound would match everything while the run reported itself as scoped, which
 * is a fabricated boundary. Such streams are collected whole and reported as
 * out-of-scope instead.
 */
export function resolveScopedStreamTimeRanges(
  scope: CollectionScope | null | undefined,
  timeScopableStreams: readonly string[] = []
): CollectorStreamTimeRanges {
  const since = typeof scope?.since === "string" ? scope.since.trim() : "";
  if (!since || Number.isNaN(Date.parse(since))) {
    return {};
  }
  const ranges: Record<string, { since: string }> = {};
  for (const stream of timeScopableStreams) {
    ranges[stream] = { since };
  }
  return Object.freeze(ranges);
}

/**
 * Resolve the owner-declared path roots a run must stay inside.
 *
 * Unlike a time bound, roots apply to every stream a connector enumerates:
 * membership is decidable from the path itself, so no manifest time field is
 * needed to prove it. Empty means no path narrowing.
 */
export function resolveScopedSourceRoots(scope: CollectionScope | null | undefined): readonly string[] {
  if (!Array.isArray(scope?.source_roots)) {
    return [];
  }
  return [
    ...new Set(scope.source_roots.filter((root) => typeof root === "string" && root.trim()).map((r) => r.trim())),
  ].sort();
}

export function buildCollectorStartMessage(
  streams: readonly string[],
  streamsToBackfill: readonly string[] = [],
  priorState?: Readonly<Record<string, unknown>> | null,
  resources: Readonly<Record<string, readonly string[]>> = {},
  timeRanges: CollectorStreamTimeRanges = {},
  sourceRoots: readonly string[] = []
): StartMessage {
  const start: StartMessage = {
    scope: {
      streams: streams.map((name): StreamScope => {
        const streamResources = resources[name]?.filter((value) => typeof value === "string" && value.length > 0);
        const timeRange = timeRanges[name];
        return {
          name,
          ...(streamResources && streamResources.length > 0 ? { resources: streamResources } : {}),
          // Only streams the caller proved scopable carry a bound. A stream
          // absent from `timeRanges` is collected whole rather than silently
          // narrowed against a field it does not have.
          ...(timeRange ? { time_range: { since: timeRange.since } } : {}),
          // Path roots ride on EVERY stream, unlike a time bound: root
          // membership is a decidable property of the path, so it needs no
          // per-stream `consent_time_field` to be provable. This is what lets a
          // connector prune subtrees before it opens anything.
          ...(sourceRoots.length > 0 ? { source_roots: [...sourceRoots] } : {}),
        };
      }),
    },
    type: "START",
  };
  if (streamsToBackfill.length > 0) {
    start.streamsToBackfill = [...streamsToBackfill];
  }
  if (priorState && Object.keys(priorState).length > 0) {
    // The reserved scope entry rides on the same state read as the cursors but
    // is not one: handing it to the connector would present a policy envelope
    // as a stream checkpoint.
    const { [COLLECTION_SCOPE_STATE_KEY]: _scope, ...cursors } = priorState;
    if (Object.keys(cursors).length > 0) {
      start.state = cursors;
    }
  }
  return start;
}

export function transformRecordsToCollectorEnvelopes(input: {
  batchId: string;
  batchSeq: number;
  connectorId: string;
  deviceId: string;
  messages: readonly EmittedMessage[];
  sourceInstanceId: string;
}): LocalDeviceRecordEnvelope[] {
  return input.messages
    .filter((msg): msg is Extract<EmittedMessage, { type: "RECORD" }> => msg.type === "RECORD")
    .map((record) =>
      buildLocalDeviceRecordEnvelope({
        batchId: input.batchId,
        batchSeq: input.batchSeq,
        connectorId: input.connectorId,
        deviceId: input.deviceId,
        record,
        sourceInstanceId: input.sourceInstanceId,
      })
    );
}

/**
 * `record_batch` outbox payload shape. Validated narrowly before sending
 * so malformed rows dead-letter instead of poisoning the drain loop.
 */
export interface RecordBatchPayload {
  batchId: string;
  batchSeq: number;
  connectorId: string;
  deviceId: string;
  records: LocalDeviceRecordEnvelope[];
  sourceInstanceId: string;
}

/**
 * `checkpoint` outbox payload shape. Validated narrowly before sending.
 */
export interface CheckpointPayload {
  connectorId: string;
  sourceInstanceId: string;
  state: Record<string, unknown>;
}

export type TerminalRunCommitPayload = TerminalRunCommitRequest;

/**
 * Machine-readable reason taxonomy for `gap` outbox rows. Kept narrow to
 * runner-knowable conditions so connector-specific failure modes do not
 * leak into a shared schema. Connectors that need richer reasons can
 * carry them as opaque `details` in {@link GapPayload}.
 *
 * - `policy_budget`: the runner deferred work because a configured bound
 *   (queue depth, duration, etc.) would otherwise grow the backlog past
 *   the policy ceiling. Retryable: a future invocation can drain and try
 *   again.
 * - `connector_child_failure`: the connector child process exited
 *   abnormally (non-zero exit, stream parse error, or stdin close)
 *   after the runner already flushed at least one durable record batch
 *   for this source instance. The boundary that was partially covered
 *   is preserved so the next invocation can target it.
 */
export type GapReason = "policy_budget" | "connector_child_failure";

/**
 * `gap` outbox payload shape. Records known incomplete or deferred work
 * the runner can describe generically. Stream/boundary identity is
 * optional because the runner cannot always know which stream a child
 * failed on; when absent the gap is scoped to the source instance.
 *
 * Payload fields are stable across re-observations so re-enqueue with a
 * deterministic id is idempotent. Per-attempt metadata (last-attempt
 * timestamp, attempt count, next attempt time) lives on the outbox row
 * itself (`updated_at`, `attempt_count`, `next_attempt_at`,
 * `last_error`) — not in the payload — so an operator surface can
 * project both first-seen (payload) and last-attempt (row) without
 * mutating the body hash.
 *
 * Validated narrowly before sending so malformed rows dead-letter
 * instead of poisoning the drain loop.
 */
export interface GapPayload {
  connectorId: string;
  /** Opaque diagnostic detail (already-redacted free-form text). */
  details?: string;
  /** ISO timestamp of the first run that observed this gap. */
  firstSeenAt: string;
  /** Run id of the first run that observed this gap, when known. */
  firstSeenRunId?: string;
  /**
   * Next-attempt policy hint, expressed as a bounded backoff in
   * milliseconds. The drain loop owns actual scheduling; this field
   * advertises the intended cadence so operator surfaces can show
   * "retries every N minutes" without inspecting drain code.
   */
  nextAttemptBackoffMs: number;
  reason: GapReason;
  /**
   * When true, the gap describes work that can still be retried (e.g.
   * policy budget). When false, the gap is terminal until external
   * action resolves it. Gap rows track retryability semantically; the
   * outbox row status still moves only via leases.
   */
  retryable: boolean;
  sourceInstanceId: string;
  /** Optional stream name when the runner can attribute the gap. */
  stream?: string;
  /**
   * Optional opaque boundary identity (e.g. a partition key, file path,
   * date window). Free-form; the runner does not interpret it.
   */
  streamBoundary?: string;
}

interface EnsureGapInput {
  clock: () => Date;
  connectorId: string;
  details?: string;
  outbox: LocalDeviceOutbox;
  reason: GapReason;
  retryable: boolean;
  runId?: string;
  sourceInstanceId: string;
  stream?: string;
  streamBoundary?: string;
}

/**
 * Persist a gap row durably for the given source instance. Idempotent
 * over the (connectorId, sourceInstanceId, reason, stream, streamBoundary)
 * tuple so re-observing the same condition on a later run does not
 * accumulate new rows — last-attempt metadata is observable from the
 * existing outbox row's `updated_at`/`next_attempt_at`/`attempt_count`
 * after the drain leases it again.
 */
function ensureCollectorGapRow(input: EnsureGapInput): LocalDeviceOutboxItem {
  const firstSeenAt = input.clock().toISOString();
  const idParts: unknown[] = [
    input.connectorId,
    input.sourceInstanceId,
    input.reason,
    input.stream ?? null,
    input.streamBoundary ?? null,
  ];
  const id = buildLocalDeviceOutboxId({
    kind: "gap",
    parts: idParts,
    sourceInstanceId: input.sourceInstanceId,
  });
  const existing = input.outbox.get(id);
  if (existing) {
    return existing;
  }
  const payload: GapPayload = {
    connectorId: input.connectorId,
    firstSeenAt,
    nextAttemptBackoffMs: DEFAULT_GAP_RETRY_BACKOFF_MS,
    reason: input.reason,
    retryable: input.retryable,
    sourceInstanceId: input.sourceInstanceId,
  };
  if (input.stream) {
    payload.stream = input.stream;
  }
  if (input.streamBoundary) {
    payload.streamBoundary = input.streamBoundary;
  }
  if (input.runId) {
    payload.firstSeenRunId = input.runId;
  }
  const details = input.details ? sanitizeCollectorGapDetails(input.details) : null;
  if (details) {
    payload.details = details;
  }
  return input.outbox.enqueue({
    id,
    kind: "gap",
    payload,
    sourceInstanceId: input.sourceInstanceId,
  });
}

function sanitizeCollectorGapDetails(value: string): string {
  let next = String(value)
    .replace(KEYED_SECRET_RE, (_match, marker: string) => `${marker}=[REDACTED]`)
    .replace(OTP_RE, "[REDACTED_OTP]")
    .replace(LONG_OPAQUE_RE, "[REDACTED]")
    .replace(/\s+/g, " ")
    .trim();
  if (next.length > COLLECTOR_GAP_DETAILS_MAX_CHARS) {
    next = `${next.slice(0, COLLECTOR_GAP_DETAILS_MAX_CHARS - 1)}…`;
  }
  return next;
}

export interface DrainCollectorOutboxInput {
  abortSignal?: AbortSignal;
  client: Pick<LocalDeviceClient, "ackLocalCollectorGap" | "ingestBatch" | "putSourceInstanceState"> &
    Partial<Pick<LocalDeviceClient, "commitTerminalRun">>;
  connectorId: string;
  holderId: string;
  outbox: LocalDeviceOutbox;
  policy: CollectorOutboxPolicy;
  sourceInstanceId?: string;
}

export interface DrainCollectorOutboxResult {
  deadLettered: number;
  /** True when the drain stopped because the duration budget was exceeded. */
  durationBudgetExceeded: boolean;
  failed: number;
  iterations: number;
  sent: number;
  /** Acknowledged-this-pass counts broken down by outbox row kind. */
  sentByKind: Readonly<Partial<Record<LocalDeviceOutboxItem["kind"], number>>>;
}

/**
 * Drain ready durable outbox rows for a source instance.
 *
 * Acknowledges only after a successful destination call. Retries with
 * bounded backoff up to `policy.maxAttempts`, then dead-letters the row
 * so it stops occupying drain bandwidth.
 *
 * Iterates at most `policy.maxDrainIterations` times so a single
 * invocation cannot spin. Remaining ready rows surface via the next
 * runner pass.
 */
export async function drainCollectorOutbox(input: DrainCollectorOutboxInput): Promise<DrainCollectorOutboxResult> {
  const sentByKind: Partial<Record<LocalDeviceOutboxItem["kind"], number>> = {};
  const result: DrainCollectorOutboxResult = {
    deadLettered: 0,
    durationBudgetExceeded: false,
    failed: 0,
    iterations: 0,
    sent: 0,
    sentByKind,
  };
  const startedAt = Date.now();
  for (let i = 0; i < input.policy.maxDrainIterations; i += 1) {
    throwIfAborted(input.abortSignal);
    const elapsedMs = Date.now() - startedAt;
    if (elapsedMs >= input.policy.maxDrainDurationMs) {
      result.durationBudgetExceeded = true;
      return result;
    }
    const claimed = claimReadyOutboxItems(input);
    if (claimed.length === 0) {
      const outcome = resolveEmptyClaimOutcome(input, elapsedMs);
      if (outcome.kind === "exit") {
        return result;
      }
      if (outcome.kind === "budget_exceeded") {
        result.durationBudgetExceeded = true;
        return result;
      }
      if (outcome.kind === "wait") {
        await waitMs_(outcome.waitMs, input.abortSignal);
      }
      continue;
    }
    result.iterations += 1;
    for (const item of claimed) {
      await drainClaimedOutboxItem(input, item, result, sentByKind);
    }
  }
  return result;
}

type EmptyClaimOutcome =
  | { kind: "budget_exceeded" }
  | { kind: "exit" }
  | { kind: "recheck" }
  | { kind: "wait"; waitMs: number };

/**
 * Decide how the drain loop proceeds when no ready row was claimable.
 *
 * `nextRetryTime` only reports rows strictly in the future
 * (`next_attempt_at > now`). A row whose backoff elapsed in the gap
 * between that clock read and `claimReadyOutboxItems`'s own (earlier)
 * clock read is neither claimable-yet by that stale read nor "in the
 * future" by this fresh one, so it falls through both checks.
 * Re-checking claimability with a fresh clock read before giving up
 * closes that race instead of abandoning a due row. The recheck uses
 * the claim path's own gate so a permanently unclaimable head (a
 * checkpoint held back by a dead-lettered predecessor) still exits
 * instead of spinning out the iteration budget.
 */
function resolveEmptyClaimOutcome(input: DrainCollectorOutboxInput, elapsedMs: number): EmptyClaimOutcome {
  const nextRetry = input.outbox.nextRetryTime(
    input.sourceInstanceId ? { sourceInstanceId: input.sourceInstanceId } : {}
  );
  if (!nextRetry) {
    return claimableReadyOutboxItem(input) ? { kind: "recheck" } : { kind: "exit" };
  }
  const nextRetryMs = new Date(nextRetry).getTime();
  const nowMs = Date.now();
  if (nextRetryMs <= nowMs) {
    return { kind: "recheck" };
  }
  const waitMs = nextRetryMs - nowMs;
  const remainingBudgetMs = input.policy.maxDrainDurationMs - elapsedMs;
  if (waitMs >= remainingBudgetMs) {
    return { kind: "budget_exceeded" };
  }
  return { kind: "wait", waitMs };
}

function waitMs_(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason instanceof Error ? signal.reason : new DOMException("Aborted", "AbortError"));
      return;
    }
    let finished = false;
    let timer: NodeJS.Timeout | undefined;
    const cleanup = () => {
      if (signal) {
        signal.removeEventListener("abort", onAbort);
      }
      if (timer !== undefined) {
        clearTimeout(timer);
      }
    };
    const onAbort = () => {
      if (finished) {
        return;
      }
      finished = true;
      cleanup();
      reject(signal?.reason instanceof Error ? signal.reason : new DOMException("Aborted", "AbortError"));
    };
    timer = setTimeout(() => {
      if (finished) {
        return;
      }
      finished = true;
      cleanup();
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

function claimReadyOutboxItems(input: DrainCollectorOutboxInput): LocalDeviceOutboxItem[] {
  const nextReady = claimableReadyOutboxItem(input);
  if (!nextReady) {
    return [];
  }
  const isCommitBoundary = nextReady.kind === "checkpoint" || nextReady.kind === "terminal_run_commit";
  const claimInput: Parameters<LocalDeviceOutbox["claimReady"]>[0] = {
    excludeKinds: isCommitBoundary ? [] : ["checkpoint", "terminal_run_commit"],
    holder: input.holderId,
    leaseMs: input.policy.leaseMs,
    limit: isCommitBoundary ? 1 : input.policy.drainBatchSize,
  };
  if (input.sourceInstanceId) {
    claimInput.sourceInstanceId = input.sourceInstanceId;
  }
  return input.outbox.claimReady(claimInput);
}

function nextReadyOutboxItem(input: DrainCollectorOutboxInput): LocalDeviceOutboxItem | null {
  return input.outbox.peekReady(input.sourceInstanceId ? { sourceInstanceId: input.sourceInstanceId } : {});
}

/**
 * The head of the ready queue if this drain may claim it right now:
 * `null` when nothing is ready, or when the head is a checkpoint held
 * back by a non-succeeded record_batch/gap predecessor.
 */
function claimableReadyOutboxItem(input: DrainCollectorOutboxInput): LocalDeviceOutboxItem | null {
  const nextReady = nextReadyOutboxItem(input);
  if (!nextReady) {
    return null;
  }
  if (
    (nextReady.kind === "checkpoint" || nextReady.kind === "terminal_run_commit") &&
    hasCheckpointPredecessorBlockingWork(input.outbox, nextReady)
  ) {
    return null;
  }
  return nextReady;
}

function hasCheckpointPredecessorBlockingWork(outbox: LocalDeviceOutbox, checkpoint: LocalDeviceOutboxItem): boolean {
  return outbox.hasNonSucceededPredecessor({
    beforeInsertOrder: checkpoint.insert_order,
    kinds: ["record_batch", "gap"],
    sourceInstanceId: checkpoint.source_instance_id,
  });
}

async function drainClaimedOutboxItem(
  input: DrainCollectorOutboxInput,
  item: LocalDeviceOutboxItem,
  result: DrainCollectorOutboxResult,
  sentByKind: Partial<Record<LocalDeviceOutboxItem["kind"], number>>
): Promise<void> {
  throwIfAborted(input.abortSignal);
  try {
    const current = input.outbox.renewLease({
      holder: input.holderId,
      id: item.id,
      leaseEpoch: item.lease_epoch,
      leaseMs: input.policy.leaseMs,
    });
    await sendOutboxItem(input.client, current);
    input.outbox.acknowledge({
      holder: input.holderId,
      id: current.id,
      leaseEpoch: current.lease_epoch,
    });
    result.sent += 1;
    sentByKind[current.kind] = (sentByKind[current.kind] ?? 0) + 1;
  } catch (error) {
    failOutboxItem(input, item, error, result);
  }
}

function failOutboxItem(
  input: DrainCollectorOutboxInput,
  item: LocalDeviceOutboxItem,
  error: unknown,
  result: DrainCollectorOutboxResult
): void {
  // Redact and bound the error before it is persisted in `last_error`.
  // `LocalDeviceHttpError` already exposes only a sanitized envelope detail
  // (code/param/message), but `failOutboxItem` is the generic persistence
  // boundary for every error type, so we re-apply the same secret/length
  // sanitizer here. This guarantees the durable outbox never stores tokens,
  // cookies, OTPs, opaque credentials, or unbounded request/response bodies
  // regardless of which error reached this path.
  const message = sanitizeCollectorGapDetails(error instanceof Error ? error.message : String(error));
  try {
    const isExplicitTransient = !(error instanceof OutboxPayloadShapeError) && classifyLocalDeviceFailure(error);
    const isTerminalCommitRejection =
      item.kind === "terminal_run_commit" &&
      ((error instanceof LocalDeviceHttpError &&
        error.status >= 400 &&
        error.status < 500 &&
        error.status !== 408 &&
        error.status !== 429) ||
        error instanceof LocalDeviceReceiptValidationError);
    const isTerminal =
      error instanceof OutboxPayloadShapeError ||
      isTerminalCommitRejection ||
      (!isExplicitTransient && item.attempt_count + 1 >= input.policy.maxAttempts);
    if (isTerminal) {
      input.outbox.deadLetter({
        error: message,
        holder: input.holderId,
        id: item.id,
        leaseEpoch: item.lease_epoch,
      });
      result.deadLettered += 1;
      return;
    }
    const serverRetryAfterMs = error instanceof LocalDeviceHttpError ? error.retryAfterMs : null;
    const retryBackoffMs =
      isExplicitTransient && serverRetryAfterMs !== null
        ? Math.min(serverRetryAfterMs, input.policy.maxRetryAfterMs)
        : input.policy.retryBackoffMs * (item.attempt_count + 1);
    input.outbox.failRetryable({
      error: message,
      holder: input.holderId,
      id: item.id,
      leaseEpoch: item.lease_epoch,
      retryBackoffMs,
    });
    result.failed += 1;
  } catch (transitionError) {
    if (isLeaseNotCurrentError(transitionError)) {
      result.failed += 1;
      return;
    }
    throw transitionError;
  }
}

function isLeaseNotCurrentError(error: unknown): boolean {
  return error instanceof Error && error.message.startsWith("local outbox lease not current");
}

class OutboxPayloadShapeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OutboxPayloadShapeError";
  }
}

/**
 * Default next-attempt backoff hint advertised in {@link GapPayload}. The
 * payload value is a stable description of the cadence at which the
 * runner would re-observe the same gap on a future invocation; the
 * actual drain scheduling is owned by the outbox lease + retry policy,
 * not by this field.
 */
const DEFAULT_GAP_RETRY_BACKOFF_MS = 15 * 60_000;

async function sendOutboxItem(
  client: Pick<LocalDeviceClient, "ackLocalCollectorGap" | "ingestBatch" | "putSourceInstanceState"> &
    Partial<Pick<LocalDeviceClient, "commitTerminalRun">>,
  item: LocalDeviceOutboxItem
): Promise<void> {
  if (item.kind === "record_batch") {
    const payload = assertRecordBatchPayload(item.payload, item.id);
    if (payload.records.length === 0) {
      throw new OutboxPayloadShapeError(`record_batch payload has no records: ${item.id}`);
    }
    await client.ingestBatch(
      buildLocalDeviceIngestBatchRequest({
        batchId: payload.batchId,
        batchSeq: payload.batchSeq,
        connectorId: payload.connectorId,
        deviceId: payload.deviceId,
        records: payload.records,
        sourceInstanceId: payload.sourceInstanceId,
      })
    );
    return;
  }
  if (item.kind === "checkpoint") {
    const payload = assertCheckpointPayload(item.payload, item.id);
    await client.putSourceInstanceState({
      sourceInstanceId: payload.sourceInstanceId,
      state: payload.state,
    });
    return;
  }
  if (item.kind === "terminal_run_commit") {
    if (!client.commitTerminalRun) {
      throw new OutboxPayloadShapeError("collector client does not support terminal_run_commit; upgrade required");
    }
    await client.commitTerminalRun(assertTerminalRunCommitPayload(item.payload, item.id));
    return;
  }
  if (item.kind === "gap") {
    // Validate first so a malformed gap dead-letters via OutboxPayloadShapeError
    // before any HTTP call.
    const payload = assertGapPayload(item.payload, item.id);
    await client.ackLocalCollectorGap({
      connector_id: payload.connectorId,
      first_seen_at: payload.firstSeenAt,
      next_attempt_backoff_ms: payload.nextAttemptBackoffMs,
      reason: payload.reason,
      retryable: payload.retryable,
      source_instance_id: payload.sourceInstanceId,
      ...(payload.stream ? { stream: payload.stream } : {}),
      ...(payload.streamBoundary ? { stream_boundary: payload.streamBoundary } : {}),
      ...(payload.firstSeenRunId ? { first_seen_run_id: payload.firstSeenRunId } : {}),
      ...(payload.firstSeenRunId ? { last_run_id: payload.firstSeenRunId } : {}),
      ...(payload.details ? { details: payload.details } : {}),
    });
    return;
  }
  throw new OutboxPayloadShapeError(`unsupported outbox kind ${item.kind} for id ${item.id}`);
}

function assertRecordBatchPayload(payload: unknown, id: string): RecordBatchPayload {
  if (!isRecord(payload)) {
    throw new OutboxPayloadShapeError(`record_batch payload is not an object: ${id}`);
  }
  if (
    typeof payload.batchId !== "string" ||
    typeof payload.batchSeq !== "number" ||
    typeof payload.connectorId !== "string" ||
    typeof payload.deviceId !== "string" ||
    typeof payload.sourceInstanceId !== "string" ||
    !Array.isArray(payload.records) ||
    !payload.records.every(isLocalDeviceRecordEnvelope)
  ) {
    throw new OutboxPayloadShapeError(`record_batch payload missing required fields: ${id}`);
  }
  return {
    batchId: payload.batchId,
    batchSeq: payload.batchSeq,
    connectorId: payload.connectorId,
    deviceId: payload.deviceId,
    records: payload.records,
    sourceInstanceId: payload.sourceInstanceId,
  };
}

function assertGapPayload(payload: unknown, id: string): GapPayload {
  if (!isRecord(payload)) {
    throw new OutboxPayloadShapeError(`gap payload is not an object: ${id}`);
  }
  if (
    typeof payload.connectorId !== "string" ||
    typeof payload.sourceInstanceId !== "string" ||
    typeof payload.firstSeenAt !== "string" ||
    typeof payload.nextAttemptBackoffMs !== "number" ||
    typeof payload.retryable !== "boolean" ||
    (payload.reason !== "policy_budget" && payload.reason !== "connector_child_failure") ||
    (payload.stream !== undefined && typeof payload.stream !== "string") ||
    (payload.streamBoundary !== undefined && typeof payload.streamBoundary !== "string") ||
    (payload.firstSeenRunId !== undefined && typeof payload.firstSeenRunId !== "string") ||
    (payload.details !== undefined && typeof payload.details !== "string")
  ) {
    throw new OutboxPayloadShapeError(`gap payload missing or invalid fields: ${id}`);
  }
  const gap: GapPayload = {
    connectorId: payload.connectorId,
    firstSeenAt: payload.firstSeenAt,
    nextAttemptBackoffMs: payload.nextAttemptBackoffMs,
    reason: payload.reason,
    retryable: payload.retryable,
    sourceInstanceId: payload.sourceInstanceId,
  };
  if (typeof payload.stream === "string") {
    gap.stream = payload.stream;
  }
  if (typeof payload.streamBoundary === "string") {
    gap.streamBoundary = payload.streamBoundary;
  }
  if (typeof payload.firstSeenRunId === "string") {
    gap.firstSeenRunId = payload.firstSeenRunId;
  }
  if (typeof payload.details === "string") {
    gap.details = payload.details;
  }
  return gap;
}

function assertCheckpointPayload(payload: unknown, id: string): CheckpointPayload {
  if (!isRecord(payload)) {
    throw new OutboxPayloadShapeError(`checkpoint payload is not an object: ${id}`);
  }
  if (
    typeof payload.connectorId !== "string" ||
    typeof payload.sourceInstanceId !== "string" ||
    !isRecord(payload.state)
  ) {
    throw new OutboxPayloadShapeError(`checkpoint payload missing required fields: ${id}`);
  }
  return {
    connectorId: payload.connectorId,
    sourceInstanceId: payload.sourceInstanceId,
    state: payload.state,
  };
}

function assertTerminalRunCommitPayload(payload: unknown, id: string): TerminalRunCommitPayload {
  if (!isRecord(payload)) {
    throw new OutboxPayloadShapeError(`terminal_run_commit payload is not an object: ${id}`);
  }
  if (
    payload.version !== 1 ||
    typeof payload.commit_id !== "string" ||
    typeof payload.run_id !== "string" ||
    typeof payload.device_id !== "string" ||
    typeof payload.connector_id !== "string" ||
    typeof payload.connector_instance_id !== "string" ||
    typeof payload.source_instance_id !== "string" ||
    typeof payload.collection_boundary !== "string" ||
    !isRecord(payload.state_delta) ||
    !Array.isArray(payload.terminal_facts) ||
    payload.terminal_facts.length === 0 ||
    !payload.terminal_facts.every(isTerminalCollectionFact)
  ) {
    throw new OutboxPayloadShapeError(`terminal_run_commit payload missing or invalid fields: ${id}`);
  }
  return {
    collection_boundary: payload.collection_boundary,
    commit_id: payload.commit_id,
    connector_id: payload.connector_id,
    connector_instance_id: payload.connector_instance_id,
    device_id: payload.device_id,
    run_id: payload.run_id,
    source_instance_id: payload.source_instance_id,
    state_delta: payload.state_delta,
    terminal_facts: payload.terminal_facts.filter(isTerminalCollectionFact),
    version: 1,
  };
}

function isTerminalCollectionFact(value: unknown): value is TerminalCollectionFact {
  return (
    isRecord(value) &&
    typeof value.stream === "string" &&
    value.stream.length > 0 &&
    Array.isArray(value.coverage_statuses) &&
    value.coverage_statuses.length > 0 &&
    value.coverage_statuses.every((status) => typeof status === "string" && status.length > 0) &&
    (value.scoped === undefined || typeof value.scoped === "boolean")
  );
}

function isLocalDeviceRecordEnvelope(value: unknown): value is LocalDeviceRecordEnvelope {
  return (
    isRecord(value) &&
    typeof value.batch_id === "string" &&
    typeof value.batch_seq === "number" &&
    typeof value.body_hash === "string" &&
    typeof value.connector_id === "string" &&
    isRecord(value.data) &&
    typeof value.device_id === "string" &&
    typeof value.emitted_at === "string" &&
    typeof value.record_key === "string" &&
    typeof value.source_instance_id === "string" &&
    typeof value.stream === "string"
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function buildOutboxBatchId(input: {
  batchSeq: number;
  connectorId: string;
  records: readonly Extract<EmittedMessage, { type: "RECORD" }>[];
  sourceInstanceId: string;
}): string {
  return `local-batch:${hashCanonicalJson({
    batch_seq: input.batchSeq,
    connector_id: input.connectorId,
    records: input.records.map((record) => ({
      data: record.data,
      emitted_at: record.emitted_at,
      key: String(record.key),
      stream: record.stream,
    })),
    source_instance_id: input.sourceInstanceId,
  })}`;
}

function pendingOutboxWorkCount(summary: LocalDeviceOutboxSummary): number {
  return summary.ready + summary.leased;
}

function hasScanBlockingOutboxWork(
  outbox: LocalDeviceOutbox,
  sourceInstanceId: string,
  policy: Pick<CollectorOutboxPolicy, "maxEnqueuedBatchesPerRun">
): boolean {
  if (outbox.hasNonSucceededWork({ excludeKinds: ["gap"], sourceInstanceId })) {
    return true;
  }
  return outbox.listByKind({ kind: "gap", sourceInstanceId }).some((item) => isUnresolvedScanBudgetGap(item, policy));
}

function hasCheckpointBlockingOutboxWork(outbox: LocalDeviceOutbox, sourceInstanceId: string): boolean {
  return outbox.hasNonSucceededWork({ sourceInstanceId });
}

function isUnresolvedScanBudgetGap(
  item: LocalDeviceOutboxItem,
  policy: Pick<CollectorOutboxPolicy, "maxEnqueuedBatchesPerRun">
): boolean {
  if (item.status === "dead_letter") {
    return false;
  }
  let payload: GapPayload;
  try {
    payload = assertGapPayload(item.payload, item.id);
  } catch {
    return item.status !== "succeeded";
  }
  if (payload.reason !== "policy_budget" || !payload.retryable || !payload.details) {
    return false;
  }
  const match = payload.details.match(SCAN_BATCH_LIMIT_DETAIL_RE);
  if (!match?.[1]) {
    return false;
  }
  return policy.maxEnqueuedBatchesPerRun <= Number(match[1]);
}

/**
 * The mutually exclusive lifecycle states a local collector lane can be in,
 * derived from the durable outbox alone. This is the single axis the
 * status/doctor surface and the runbook describe so an operator (or an
 * agent) reading a `pdpp-local-collector doctor` JSON never has to infer
 * the situation from raw counts.
 *
 * Priority order (most-actionable first) when several conditions overlap:
 * `dead_letter` > `stale_lease` > `retryable_backlog` > `draining` >
 * `coverage_missing` > `healthy_idle`.
 *
 * - `dead_letter`: at least one row exhausted retries and needs operator
 *   recovery (`retry-dead-letters`). Drain bandwidth is otherwise fine.
 * - `stale_lease`: a previous runner instance crashed mid-drain and left a
 *   lease past its expiry. The next run recovers it automatically; surfaced
 *   so a stuck lane is visible before then.
 * - `retryable_backlog`: ready work remains but every ready row is waiting
 *   on its retry backoff (nothing claimable this instant). Self-heals on the
 *   next scheduled run; no operator action required.
 * - `draining`: claimable-now or leased work exists — the lane is actively
 *   moving records to the server.
 * - `coverage_missing`: the lane has drained real records but never carried
 *   a `coverage_diagnostics` record, so the dashboard can only project
 *   `coverage_unknown`. Re-running with the default stream set (which
 *   includes `coverage_diagnostics`) promotes the axis. This is the local
 *   shape behind the upgrade note in the runbook.
 * - `healthy_idle`: fully drained with coverage accounted for (or nothing
 *   has been collected yet, so there is no coverage to miss).
 */
export const LOCAL_COLLECTOR_LIFECYCLE_STATES = [
  "healthy_idle",
  "draining",
  "retryable_backlog",
  "dead_letter",
  "stale_lease",
  "coverage_missing",
] as const;

export type LocalCollectorLifecycleState = (typeof LOCAL_COLLECTOR_LIFECYCLE_STATES)[number];

export interface LocalCollectorLifecycleInput {
  /**
   * Whether the lane has durably carried a `coverage_diagnostics` record.
   * When the caller cannot determine this (e.g. an unscoped status with no
   * connection id), pass `null` to suppress the `coverage_missing` verdict
   * rather than guess.
   */
  coverageObserved: boolean | null;
  /**
   * Count of non-dead-letter `record_batch` rows for the lane. Used to tell
   * an empty/never-run lane (no coverage to miss) apart from one that has
   * collected records but no coverage diagnostic.
   */
  recordBatchCount: number;
  summary: LocalDeviceOutboxSummary;
}

/**
 * Derive the single mutually-exclusive {@link LocalCollectorLifecycleState}
 * for a lane from its durable outbox summary plus the coverage observation.
 * Pure and side-effect free so both the heartbeat path and the CLI doctor
 * read the same taxonomy.
 */
export function deriveLocalCollectorLifecycleState(input: LocalCollectorLifecycleInput): LocalCollectorLifecycleState {
  const { summary } = input;
  if (summary.deadLetter > 0) {
    return "dead_letter";
  }
  if (summary.staleLeases > 0) {
    return "stale_lease";
  }
  const claimableNow = Math.max(0, summary.ready - summary.retrying);
  if (summary.leased > 0 || claimableNow > 0) {
    return "draining";
  }
  if (summary.retrying > 0) {
    return "retryable_backlog";
  }
  // Fully drained from here down. Coverage is only "missing" when the lane
  // has actually collected records but none of them was a coverage
  // diagnostic; an empty lane has no coverage to miss, and a null
  // observation means the caller could not check (do not guess).
  if (input.coverageObserved === false && input.recordBatchCount > 0) {
    return "coverage_missing";
  }
  return "healthy_idle";
}

function heartbeatStatusForSummary(
  summary: LocalDeviceOutboxSummary,
  policy?: Pick<CollectorOutboxPolicy, "maxQueueDepth">,
  backlogOpen = 0
): "blocked" | "healthy" | "retrying" {
  if (summary.deadLetter > 0 || backlogOpen > 0) {
    return "blocked";
  }
  const pending = pendingOutboxWorkCount(summary);
  if (policy && pending >= policy.maxQueueDepth) {
    return "blocked";
  }
  if (pending > 0) {
    return "retrying";
  }
  return "healthy";
}

export function buildHeartbeatOutboxDiagnostics(
  summary: LocalDeviceOutboxSummary,
  options: { backlogOpen?: number } = {}
): HeartbeatOutboxDiagnostics {
  return {
    backlog_open: Math.max(0, options.backlogOpen ?? 0),
    dead_letter: summary.deadLetter,
    leased: summary.leased,
    oldest_pending_at: summary.oldestReadyAt,
    oldest_retrying_at: summary.oldestRetryingAt,
    pending: summary.ready,
    retrying: summary.retrying,
    stale_leases: summary.staleLeases,
    succeeded: summary.succeeded,
    total: summary.total,
  };
}

/**
 * Build the redacted `last_error` carried on a heartbeat when the source
 * instance has a dead-letter backlog. Returns null when there are no
 * dead-letter rows so a healthy/draining heartbeat stays quiet. The
 * `top_dead_letter_classes` are already redaction-safe at the outbox
 * boundary; the reference server re-sanitizes them before persistence.
 *
 * This is what lets the dashboard answer "why did these dead-letter?"
 * instead of showing `last_error_json: null` — the cause already lives on
 * each row's `last_error` column but was never propagated up the heartbeat.
 */
function buildHeartbeatDeadLetterError(outbox: LocalDeviceOutbox, sourceInstanceId: string): HeartbeatLastError | null {
  const summary = outbox.deadLetterErrorSummary({ sourceInstanceId });
  if (summary.dead_letter_count === 0) {
    return null;
  }
  return {
    kind: "dead_letter_backlog",
    top_dead_letter_classes: summary.top_classes,
  };
}

function countOpenBacklogGaps(outbox: LocalDeviceOutbox, sourceInstanceId: string): number {
  return outbox.countOpenGaps({ sourceInstanceId });
}

function nextOutboxBatchSeq(outbox: LocalDeviceOutbox, sourceInstanceId: string): number {
  return outbox.maxRecordBatchSeq({ sourceInstanceId }) + 1;
}

export async function drainCollectorQueue(input: {
  abortSignal?: AbortSignal;
  client: Pick<LocalDeviceClient, "ingestBatch">;
  queue: LocalDeviceQueue;
}): Promise<number> {
  let sent = 0;
  for (;;) {
    throwIfAborted(input.abortSignal);
    const item = await input.queue.dequeueReady();
    if (!item) {
      return sent;
    }
    try {
      await sendQueueItem(input.client, item);
      await input.queue.markSent(item.batch_id);
      sent += 1;
    } catch (error) {
      await input.queue.markRetry(item.batch_id, error instanceof Error ? error.message : String(error));
      return sent;
    }
  }
}

/**
 * Drain-before-scan helper for the durable outbox path.
 *
 * Recovers expired leases first so any work abandoned by a previous
 * runner becomes claimable, then exposes a summary the caller can use
 * to decide whether to scan a source for new work or finish out the
 * existing backlog. Matches the design-note ordering: recover, drain
 * acknowledged-safe pending work, only then scan more source data.
 */
export function recoverAndSummarizeOutbox(
  outbox: Pick<LocalDeviceOutbox, "recoverExpiredLeases" | "summary">,
  input: { sourceInstanceId?: string } = {}
): { recovered: number; summary: ReturnType<LocalDeviceOutbox["summary"]> } {
  const recovered = input.sourceInstanceId
    ? outbox.recoverExpiredLeases({ sourceInstanceId: input.sourceInstanceId })
    : outbox.recoverExpiredLeases();
  const summary = input.sourceInstanceId
    ? outbox.summary({ sourceInstanceId: input.sourceInstanceId })
    : outbox.summary();
  return { recovered, summary };
}

function throwIfAborted(signal: AbortSignal | undefined): void {
  if (signal?.aborted) {
    throw signal.reason instanceof Error ? signal.reason : new DOMException("Aborted", "AbortError");
  }
}

async function sendQueueItem(
  client: Pick<LocalDeviceClient, "ingestBatch">,
  item: LocalDeviceQueueItem
): Promise<void> {
  const [firstRecord] = item.records;
  if (!firstRecord) {
    throw new Error(`collector batch has no records: ${item.batch_id}`);
  }
  await client.ingestBatch(
    buildLocalDeviceIngestBatchRequest({
      batchId: item.batch_id,
      batchSeq: item.batch_seq,
      connectorId: firstRecord.connector_id,
      deviceId: firstRecord.device_id,
      records: item.records,
      sourceInstanceId: item.source_instance_id,
    })
  );
}

/**
 * Collector context the connector subprocess needs in env beyond
 * `connector.env`. The streaming-registration plumbing (see
 * `connector-runtime.ts → resolveStreamingRegistrationFromEnv`)
 * reads these to construct a registration client.
 */
export interface CollectorChildContext {
  /** Reference server base URL (forwarded as PDPP_REFERENCE_BASE_URL). */
  readonly baseUrl: string;
  /** Device-exporter bearer token (forwarded as PDPP_LOCAL_DEVICE_TOKEN). */
  readonly deviceToken: string;
  /** Optional run id (forwarded as PDPP_RUN_ID). Omit to skip streaming. */
  readonly runId?: string;
}

function buildCollectorChildEnv(context: CollectorChildContext): Record<string, string> {
  const env: Record<string, string> = {
    PDPP_LOCAL_DEVICE_TOKEN: context.deviceToken,
    PDPP_REFERENCE_BASE_URL: context.baseUrl,
  };
  if (context.runId) {
    env.PDPP_RUN_ID = context.runId;
  }
  return env;
}

/**
 * Fixed-capacity stderr ring. Connectors emitting verbose progress logs
 * can otherwise pin proportional heap during long backfills. We retain
 * the tail (which carries the actionable failure message) and prepend a
 * truncation marker when bytes were dropped.
 */
class BoundedStderrBuffer {
  readonly #limit: number;
  readonly #chunks: Buffer[] = [];
  #size = 0;
  #dropped = 0;

  constructor(limit: number) {
    this.#limit = Math.max(1024, limit);
  }

  push(chunk: Buffer): void {
    this.#chunks.push(chunk);
    this.#size += chunk.length;
    while (this.#size > this.#limit && this.#chunks.length > 0) {
      const [head] = this.#chunks;
      if (!head) {
        break;
      }
      const overflow = this.#size - this.#limit;
      if (head.length <= overflow) {
        this.#chunks.shift();
        this.#size -= head.length;
        this.#dropped += head.length;
        continue;
      }
      this.#chunks[0] = head.subarray(overflow);
      this.#size -= overflow;
      this.#dropped += overflow;
      break;
    }
  }

  toString(): string {
    const body = Buffer.concat(this.#chunks).toString("utf8");
    if (this.#dropped === 0) {
      return body;
    }
    return `[truncated ${this.#dropped} stderr bytes]\n${body}`;
  }
}

function spawnConnector(
  connector: CollectorConnectorSpec,
  childContext: CollectorChildContext
): ChildProcessWithoutNullStreams {
  const env = {
    ...process.env,
    ...buildCollectorChildEnv(childContext),
    ...connector.env,
  };
  env.PATH = buildCollectorChildPath(env.PATH);
  return spawn(connector.command, [...connector.args], {
    cwd: PACKAGE_ROOT,
    env,
  });
}

function buildCollectorChildPath(pathValue: string | undefined): string {
  return [join(PACKAGE_ROOT, "node_modules", ".bin"), join(REPO_ROOT, "node_modules", ".bin"), pathValue]
    .filter((part): part is string => Boolean(part))
    .join(delimiter);
}
