// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import type { Socket } from "node:net";
import { test } from "node:test";
import { canonicalTerminalRunCommitEnvelope } from "@pdpp/reference-contract/common";
import { COLLECTOR_PROTOCOL_VERSION } from "./collector-protocol.ts";
import {
  LOCAL_DEVICE_ENDPOINTS,
  LocalDeviceClient,
  LocalDeviceHttpError,
  LocalDeviceReceiptValidationError,
  LocalDeviceRequestTimeoutError,
  type TerminalRunCommitRequest,
} from "./local-device-client.ts";
import { hashCanonicalJson } from "./local-device-envelope.ts";

function terminalRequest(): TerminalRunCommitRequest {
  return {
    collection_boundary: "unscoped",
    commit_id: "commit-1",
    connector_id: "codex",
    connector_instance_id: "cin-1",
    device_id: "device-1",
    run_id: "run-1",
    source_instance_id: "source-1",
    state_delta: { sessions: { cursor: "c1" } },
    terminal_facts: [{ coverage_statuses: ["collected"], stream: "sessions" }],
    version: 1,
  };
}

test("LocalDeviceClient accepts only the exact canonical terminal receipt", async () => {
  const request = terminalRequest();
  const expectedHash = hashCanonicalJson(canonicalTerminalRunCommitEnvelope(request));
  const client = new LocalDeviceClient({
    baseUrl: "http://127.0.0.1:1",
    deviceId: "device-1",
    deviceToken: "device-token",
    fetchImpl: () =>
      Promise.resolve(
        new Response(
          JSON.stringify({
            commit_id: request.commit_id,
            envelope_hash: expectedHash,
            object: "device_terminal_run_commit",
            run_id: request.run_id,
            terminal_event_id: "evt-1",
          }),
          { status: 200 }
        )
      ),
  });
  assert.equal((await client.commitTerminalRun(request)).envelope_hash, expectedHash);
});

for (const invalid of [
  {
    commit_id: "wrong",
    envelope_hash: "x",
    object: "device_terminal_run_commit",
    run_id: "run-1",
    terminal_event_id: "evt",
  },
  {
    commit_id: "commit-1",
    envelope_hash: "wrong",
    object: "device_terminal_run_commit",
    run_id: "run-1",
    terminal_event_id: "evt",
  },
  {
    commit_id: "commit-1",
    envelope_hash: "x",
    object: "device_terminal_run_commit",
    run_id: "wrong",
    terminal_event_id: "evt",
  },
  { ok: true },
] as const) {
  test(`LocalDeviceClient rejects an invalid terminal receipt: ${JSON.stringify(invalid)}`, async () => {
    const client = new LocalDeviceClient({
      baseUrl: "http://127.0.0.1:1",
      deviceId: "device-1",
      deviceToken: "device-token",
      fetchImpl: () => Promise.resolve(new Response(JSON.stringify(invalid), { status: 200 })),
    });
    await assert.rejects(client.commitTerminalRun(terminalRequest()), LocalDeviceReceiptValidationError);
  });
}

test("LocalDeviceClient sends enrollment exchange without bearer token", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    const response = await client.exchangeEnrollment({
      device_label: "Laptop",
      enrollment_code: "enroll-123",
    });

    assert.equal(response.device_id, "device-1");
    assert.equal(seen[0]?.path, LOCAL_DEVICE_ENDPOINTS.exchangeEnrollment);
    assert.equal(seen[0]?.authorization, undefined);
    assert.equal(seen[0]?.collectorProtocol, COLLECTOR_PROTOCOL_VERSION);
    assert.deepEqual(seen[0]?.body, {
      device_label: "Laptop",
      enrollment_code: "enroll-123",
    });
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient sends bearer-authenticated heartbeat and ingest batch shapes", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await client.heartbeat({
      connector_id: "codex",
      records_pending: 3,
      source_instance_id: "source-1",
      status: "healthy",
    });
    await client.ingestBatch({
      batch_id: "batch-1",
      batch_seq: 1,
      body_hash: "hash-1",
      connector_id: "codex",
      device_id: "device-1",
      records: [
        {
          data: {},
          emitted_at: "2026-04-30T12:00:00.000Z",
          record_key: "record-1",
          stream: "messages",
        },
      ],
      source_instance_id: "source-1",
    });

    assert.equal(seen[0]?.path, LOCAL_DEVICE_ENDPOINTS.heartbeat("device-1"));
    assert.equal(seen[0]?.authorization, "Bearer device-token");
    assert.equal(seen[0]?.collectorProtocol, COLLECTOR_PROTOCOL_VERSION);
    assert.deepEqual(seen[0]?.body, {
      connector_id: "codex",
      records_pending: 3,
      source_instance_id: "source-1",
      status: "healthy",
    });
    assert.equal(seen[1]?.path, LOCAL_DEVICE_ENDPOINTS.ingestBatch("device-1"));
    assert.equal(seen[1]?.authorization, "Bearer device-token");
    assert.equal(seen[1]?.collectorProtocol, COLLECTOR_PROTOCOL_VERSION);
    assert.deepEqual(seen[1]?.body, {
      batch_id: "batch-1",
      batch_seq: 1,
      body_hash: "hash-1",
      connector_id: "codex",
      device_id: "device-1",
      records: [
        {
          data: {},
          emitted_at: "2026-04-30T12:00:00.000Z",
          record_key: "record-1",
          stream: "messages",
        },
      ],
      source_instance_id: "source-1",
    });
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient sends bearer-authenticated self-revoke with no body", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await client.selfRevoke();

    assert.equal(seen[0]?.method, "POST");
    assert.equal(seen[0]?.path, LOCAL_DEVICE_ENDPOINTS.selfRevoke("device-1"));
    assert.equal(seen[0]?.authorization, "Bearer device-token");
    assert.equal(seen[0]?.collectorProtocol, COLLECTOR_PROTOCOL_VERSION);
    assert.equal(seen[0]?.body, null);
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient GET source-instance state hits the device-scoped state route with the bearer", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    const response = await client.getSourceInstanceState({
      sourceInstanceId: "source-1",
    });
    assert.equal(response.object, "device_source_instance_state");
    assert.equal(response.device_id, "device-1");
    assert.equal(response.source_instance_id, "source-1");
    assert.deepEqual(response.state, { messages: { cursor: "abc" } });
    assert.equal(seen[0]?.method, "GET");
    assert.equal(seen[0]?.path, LOCAL_DEVICE_ENDPOINTS.sourceInstanceState("device-1", "source-1"));
    assert.equal(seen[0]?.authorization, "Bearer device-token");
    assert.equal(seen[0]?.collectorProtocol, COLLECTOR_PROTOCOL_VERSION);
    // No body on GET.
    assert.equal(seen[0]?.body, null);
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient PUT source-instance state sends bearer + JSON body", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await client.putSourceInstanceState({
      sourceInstanceId: "source-1",
      state: { messages: { cursor: "next" } },
    });
    assert.equal(seen[0]?.method, "PUT");
    assert.equal(seen[0]?.path, LOCAL_DEVICE_ENDPOINTS.sourceInstanceState("device-1", "source-1"));
    assert.equal(seen[0]?.authorization, "Bearer device-token");
    assert.equal(seen[0]?.collectorProtocol, COLLECTOR_PROTOCOL_VERSION);
    assert.deepEqual(seen[0]?.body, {
      state: { messages: { cursor: "next" } },
    });
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient sends local collector gap ack and recovery through device-scoped routes", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await client.ackLocalCollectorGap({
      connector_id: "codex",
      first_seen_at: "2026-05-19T12:00:00.000Z",
      next_attempt_backoff_ms: 60_000,
      reason: "policy_budget",
      retryable: true,
      source_instance_id: "source-1",
    });
    await client.recoverLocalCollectorGap({
      connector_id: "codex",
      reason: "policy_budget",
      recovered_run_id: "run-2",
      source_instance_id: "source-1",
    });

    assert.equal(seen[0]?.method, "POST");
    assert.equal(seen[0]?.path, LOCAL_DEVICE_ENDPOINTS.localCollectorGap("device-1", "source-1"));
    assert.equal(seen[0]?.authorization, "Bearer device-token");
    assert.deepEqual(seen[0]?.body, {
      connector_id: "codex",
      first_seen_at: "2026-05-19T12:00:00.000Z",
      next_attempt_backoff_ms: 60_000,
      reason: "policy_budget",
      retryable: true,
      source_instance_id: "source-1",
    });
    assert.equal(seen[1]?.method, "POST");
    assert.equal(seen[1]?.path, LOCAL_DEVICE_ENDPOINTS.localCollectorGapRecovered("device-1", "source-1"));
    assert.deepEqual(seen[1]?.body, {
      connector_id: "codex",
      reason: "policy_budget",
      recovered_run_id: "run-2",
      source_instance_id: "source-1",
    });
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient state methods reject 401/403 with LocalDeviceHttpError", async () => {
  const server = await startStatusServer(401, "denied");
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await assert.rejects(
      () => client.getSourceInstanceState({ sourceInstanceId: "source-1" }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceHttpError);
        if (err instanceof LocalDeviceHttpError) {
          assert.equal(err.status, 401);
        }
        return true;
      }
    );
  } finally {
    await server.close();
  }
});

test("LocalDeviceHttpError surfaces a typed PDPP code from the response envelope", async () => {
  const server = await startStatusServer(
    409,
    '{"error":{"type":"conflict","code":"collector_protocol_mismatch","param":"connector_id","message":"connector_id does not match source_instance_id","accepted_versions":["2"],"received_version":"1"}}'
  );
  try {
    const client = new LocalDeviceClient({ baseUrl: server.url });
    await assert.rejects(
      () => client.exchangeEnrollment({ enrollment_code: "x" }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceHttpError);
        if (err instanceof LocalDeviceHttpError) {
          assert.equal(err.status, 409);
          assert.equal(err.code, "collector_protocol_mismatch");
          assert.equal(err.param, "connector_id");
          assert.equal(err.envelopeMessage, "connector_id does not match source_instance_id");
          assert.match(err.message, /409/);
          assert.match(err.message, /collector_protocol_mismatch/);
          assert.match(err.message, /param=connector_id/);
          assert.match(err.message, /message=connector_id does not match source_instance_id/);
        }
        return true;
      }
    );
  } finally {
    await server.close();
  }
});

test("LocalDeviceHttpError tolerates non-JSON bodies without exposing a parsed code", async () => {
  const server = await startStatusServer(502, "<html>upstream down</html>");
  try {
    const client = new LocalDeviceClient({ baseUrl: server.url });
    await assert.rejects(
      () => client.exchangeEnrollment({ enrollment_code: "x" }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceHttpError);
        if (err instanceof LocalDeviceHttpError) {
          assert.equal(err.status, 502);
          assert.equal(err.code, null);
          assert.equal(err.message.includes("<html>"), false);
        }
        return true;
      }
    );
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient state methods surface 404 unknown source instance", async () => {
  const server = await startStatusServer(404, '{"error":{"code":"not_found"}}');
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await assert.rejects(
      () => client.getSourceInstanceState({ sourceInstanceId: "missing" }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceHttpError);
        if (err instanceof LocalDeviceHttpError) {
          assert.equal(err.status, 404);
          assert.ok(err.body.includes("not_found"));
        }
        return true;
      }
    );
  } finally {
    await server.close();
  }
});

test("LocalDeviceHttpError captures Retry-After structurally, not parsed from message prose", async () => {
  // The exact incident shape: a 503 device_ingest_retryable envelope with
  // `Retry-After: 1` (reference-implementation/server/routes/ref-device-exporters.ts
  // sets this on connector_instance_busy admission saturation). Before this
  // fix, the header was discarded entirely — retryAfterMs was unreachable to
  // any caller regardless of how the message text was parsed.
  const server = await startStatusServer(
    503,
    '{"error":{"code":"device_ingest_retryable","message":"Device ingest is temporarily unavailable; retry the same batch"}}',
    { "retry-after": "1" }
  );
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await assert.rejects(
      () =>
        client.ingestBatch({
          batch_id: "b1",
          batch_seq: 1,
          body_hash: "hash-1",
          connector_id: "c1",
          device_id: "device-1",
          records: [],
          source_instance_id: "s1",
        }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceHttpError);
        if (err instanceof LocalDeviceHttpError) {
          assert.equal(err.status, 503);
          assert.equal(err.code, "device_ingest_retryable");
          assert.equal(err.retryAfterMs, 1000, "Retry-After: 1 (second) parses to 1000ms structurally");
        }
        return true;
      }
    );
  } finally {
    await server.close();
  }
});

test("LocalDeviceHttpError has a null retryAfterMs when the server sends no Retry-After header", async () => {
  const server = await startStatusServer(500, '{"error":{"code":"internal_error"}}');
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
    });
    await assert.rejects(
      () =>
        client.ingestBatch({
          batch_id: "b1",
          batch_seq: 1,
          body_hash: "hash-1",
          connector_id: "c1",
          device_id: "device-1",
          records: [],
          source_instance_id: "s1",
        }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceHttpError);
        if (err instanceof LocalDeviceHttpError) {
          assert.equal(err.retryAfterMs, null);
        }
        return true;
      }
    );
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient aborts a stalled request with LocalDeviceRequestTimeoutError instead of hanging", async () => {
  // Server accepts the connection but never responds, mimicking a reference
  // server stalled mid-request (e.g. during a projection rebuild). Without a
  // bounded timeout this `fetch` would hang until the host supervisor's
  // 15-minute start-timeout reaped the whole process.
  const server = await startStallingServer();
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
      requestTimeoutMs: 150,
    });
    const startedAt = process.hrtime.bigint();
    await assert.rejects(
      () => client.getSourceInstanceState({ sourceInstanceId: "source-1" }),
      (err: unknown) => {
        assert.ok(err instanceof LocalDeviceRequestTimeoutError, `expected timeout error, got ${String(err)}`);
        if (err instanceof LocalDeviceRequestTimeoutError) {
          assert.equal(err.timeoutMs, 150);
          assert.match(err.message, /timed out after 150ms/);
        }
        return true;
      }
    );
    const elapsedMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    // It fails fast (bounded), nowhere near a 15-minute hang.
    assert.ok(elapsedMs < 5000, `expected fast abort, took ${elapsedMs}ms`);
  } finally {
    await server.close();
  }
});

test("LocalDeviceClient requestTimeoutMs=0 disables the ceiling and lets a fast response through", async () => {
  const seen: SeenRequest[] = [];
  const server = await startJsonServer(seen);
  try {
    const client = new LocalDeviceClient({
      baseUrl: server.url,
      deviceId: "device-1",
      deviceToken: "device-token",
      requestTimeoutMs: 0,
    });
    const response = await client.getSourceInstanceState({
      sourceInstanceId: "source-1",
    });
    assert.equal(response.source_instance_id, "source-1");
    assert.equal(seen[0]?.method, "GET");
  } finally {
    await server.close();
  }
});

interface SeenRequest {
  authorization: string | undefined;
  body: unknown;
  collectorProtocol: string | undefined;
  method: string;
  path: string;
}

async function startJsonServer(seen: SeenRequest[]): Promise<{ close: () => Promise<void>; url: string }> {
  const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
    const body = await readRequestBody(req);
    const path = req.url ?? "";
    seen.push({
      authorization: req.headers.authorization,
      body: body ? JSON.parse(body) : null,
      collectorProtocol: req.headers["x-pdpp-collector-protocol"] as string | undefined,
      method: req.method ?? "",
      path,
    });
    if (path === LOCAL_DEVICE_ENDPOINTS.exchangeEnrollment) {
      sendJson(res, 200, {
        device_id: "device-1",
        device_token: "token-1",
        source_instance_id: "source-1",
      });
      return;
    }
    // Match either GET or PUT against the state route, regardless of which
    // sourceInstanceId the test used.
    if (path.endsWith("/state")) {
      const parts = path.split("/");
      const sourceInstanceId = decodeURIComponent(parts.at(-2) ?? "");
      sendJson(res, 200, {
        device_id: "device-1",
        object: "device_source_instance_state",
        source_instance_id: sourceInstanceId,
        state:
          req.method === "GET"
            ? { messages: { cursor: "abc" } }
            : ((body ? JSON.parse(body) : { state: {} }).state ?? {}),
        updated_at: "2026-04-30T12:00:00.000Z",
      });
      return;
    }
    sendJson(res, 200, { ok: true });
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  return {
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
    url: `http://127.0.0.1:${address.port}`,
  };
}

async function startStatusServer(
  status: number,
  body: string,
  headers: Record<string, string> = {}
): Promise<{ close: () => Promise<void>; url: string }> {
  const server = createServer((_req: IncomingMessage, res: ServerResponse) => {
    res.writeHead(status, { "content-type": "application/json", ...headers });
    res.end(body);
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  return {
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
    url: `http://127.0.0.1:${address.port}`,
  };
}

async function startStallingServer(): Promise<{
  close: () => Promise<void>;
  url: string;
}> {
  const sockets = new Set<Socket>();
  // Never call res.end(): the request hangs open until the client's bounded
  // timeout aborts it. Track sockets so teardown can destroy the dangling
  // connection rather than waiting on a response that never comes.
  const server: Server = createServer((_req: IncomingMessage, _res: ServerResponse) => {
    /* intentionally never responds */
  });
  server.on("connection", (socket: Socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  return {
    close: () =>
      new Promise<void>((resolve) => {
        for (const socket of sockets) {
          socket.destroy();
        }
        server.close(() => resolve());
      }),
    url: `http://127.0.0.1:${address.port}`,
  };
}

async function readRequestBody(req: IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString("utf8");
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
}
