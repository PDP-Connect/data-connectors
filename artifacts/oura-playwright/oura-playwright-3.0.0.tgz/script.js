// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

/**
 * Oura Ring Connector
 *
 * Exports:
 * - Readiness scores (daily)
 * - Sleep data (daily scores + sleep periods)
 * - Activity data (daily)
 *
 * Oura discontinues Oura on the Web (cloud.ouraring.com dashboard and its
 * private /api/account/* endpoints) on 5 Oct 2026. The Membership Hub has no
 * live health data (only an async CSV export that takes up to 10 days), so
 * this connector reads the public Oura API V2 instead:
 *
 * 1. Sign in to the Oura Developer Portal (developer.ouraring.com) with the
 *    user's Oura account (same Oura identity as the Membership Hub).
 * 2. Find or create a personal API application on the user's own developer
 *    account. Each user owns their app, so Oura's 10-users-per-unapproved-app
 *    cap never applies. The user ticks the Oura API Agreement themselves.
 * 3. Authorize that app with the OAuth2 authorization-code flow (PKCE,
 *    scope "extapi:daily") and exchange the code with the app's own client
 *    secret, read from the portal API and never logged. Oura's client-side
 *    (implicit) flow is not used: it issues tokens without scopes.
 * 4. Fetch daily_readiness, daily_sleep, sleep and daily_activity from
 *    api.ouraring.com/v2/usercollection.
 *
 * Oura's sign-in cookies are session-only, so steps 1-3 need the user in a
 * headed browser. The resulting access + refresh tokens are cached in the
 * connector's own browser profile on the developer.ouraring.com origin, so
 * scheduled re-runs stay headless and refresh the access token themselves.
 *
 * 90-day lookback window, cursor-paginated (next_token).
 *
 * Honest connector telemetry contract:
 * - Returns canonical flat result shape
 * - Explicit requestedScopes
 * - errors[] for unresolved output-affecting problems only
 * - omitted / degraded / fatal dispositions
 */

const PLATFORM = "oura";
const VERSION = "3.0.0";
const CANONICAL_SCOPES = [
  "oura.readiness",
  "oura.sleep",
  "oura.activity",
];

const DEV_PORTAL = "https://developer.ouraring.com";
const APPS_URL = `${DEV_PORTAL}/applications`;
// Oura's external-API authorization server (the legacy
// cloud.ouraring.com/oauth/authorize redirects here but drops the scope).
const AUTHORIZE_URL = "https://moi.ouraring.com/oauth/v2/ext/oauth-authorize";
const TOKEN_URL = "https://moi.ouraring.com/oauth/v2/ext/oauth-token";
const API_BASE = "https://api.ouraring.com/v2/usercollection";

const APP_NAME = "Vana Connector";
const APP_REDIRECT_URI = "https://vana.org/oauth/oura/callback";
const APP_SCOPE = "extapi:daily";
const OAUTH_SCOPE = "extapi:daily";
const TOKEN_STORAGE_KEY = "vana:oura-connector:token";

const LOOKBACK_DAYS = 90;
const INTERACTION_TIMEOUT_MS = 10 * 60 * 1000;

// Each scope maps to the API V2 collections it is built from.
const SCOPE_ENDPOINTS = {
  "oura.readiness": ["daily_readiness"],
  "oura.sleep": ["daily_sleep", "sleep"],
  "oura.activity": ["daily_activity"],
};

// ── Telemetry helpers ──────────────────────────────────────────────

const makeConnectorError = (errorClass, reason, disposition, extras = {}) => ({
  errorClass,
  reason,
  disposition,
  ...extras,
});

const makeFatalRunError = (errorClass, reason, phase = "collect") => {
  const error = new Error(reason);
  error.telemetryError = makeConnectorError(errorClass, reason, "fatal", { phase });
  return error;
};

const inferErrorClass = (message, fallback = "runtime_error") => {
  const text = String(message || "").toLowerCase();
  if (text.includes("auth") || text.includes("login") || text.includes("credential")) {
    return "auth_failed";
  }
  if (text.includes("timeout") || text.includes("timed out")) {
    return "timeout";
  }
  if (text.includes("network") || text.includes("fetch") || text.includes("net::")) {
    return "network_error";
  }
  if (text.includes("navigation") || text.includes("goto")) {
    return "navigation_error";
  }
  return fallback;
};

const buildResult = ({ requestedScopes, scopes, errors, exportSummary }) => ({
  requestedScopes: [...requestedScopes],
  timestamp: new Date().toISOString(),
  version: VERSION,
  platform: PLATFORM,
  exportSummary,
  errors,
  ...scopes,
});

const buildEmptyResult = (requestedScopes, errors) =>
  buildResult({
    requestedScopes,
    scopes: {},
    errors,
    exportSummary: {
      count: 0,
      label: "days of Oura data",
    },
  });

const resolveRequestedScopes = () => {
  const raw =
    typeof page.requestedScopes === "function" ? page.requestedScopes() : null;
  if (raw == null) {
    return [...CANONICAL_SCOPES];
  }
  if (!Array.isArray(raw) || raw.length === 0) {
    throw makeFatalRunError(
      "protocol_violation",
      "Oura connector received an empty or invalid requestedScopes array.",
      "init",
    );
  }
  const deduped = Array.from(new Set(raw));
  const invalid = deduped.filter((scope) => !CANONICAL_SCOPES.includes(scope));
  if (invalid.length > 0) {
    throw makeFatalRunError(
      "protocol_violation",
      `Oura connector received unsupported requestedScopes: ${invalid.join(", ")}.`,
      "init",
    );
  }
  return deduped;
};

// ── Resilience helpers ──────────────────────────────────────────────

const withTimeout = async (promise, ms, label) => {
  let timeoutId = null;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timeoutId = setTimeout(
          () => reject(new Error(`${label} timed out after ${ms}ms`)),
          ms,
        );
      }),
    ]);
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
};

const safeGoto = async (url, options = {}) => {
  const { attempts = 3, timeout = 20000, betweenMs = 2000, label = url } = options;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      await withTimeout(
        page.goto(url, { timeout }),
        timeout + 5000,
        `goto ${label}`,
      );
      return true;
    } catch (error) {
      const message = error?.message || String(error);
      console.error(
        `[oura] Navigation attempt ${attempt}/${attempts} failed for ${label}: ${message}`,
      );
      if (attempt < attempts) {
        await page.sleep(betweenMs);
      }
    }
  }
  return false;
};

const currentUrl = async () => {
  try {
    return String(await page.url());
  } catch {
    return "";
  }
};

// Origin + path only: never log query strings or fragments (they carry
// OAuth state and tokens).
const describeUrl = (url) => {
  try {
    const parsed = new URL(url);
    return `${parsed.origin}${parsed.pathname}`;
  } catch {
    return "(unknown page)";
  }
};

// Polls `check` until it returns a truthy value or the timeout passes.
const waitFor = async (check, timeoutMs, intervalMs = 2000) => {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const value = await check();
      if (value) return value;
    } catch {
      // keep polling
    }
    await page.sleep(intervalMs);
  }
  return null;
};

// ── Page state detection ────────────────────────────────────────────

const isOnMoiLogin = (url) => url.startsWith("https://moi.ouraring.com/authn/");
const isOnRedirect = (url) => url.startsWith(APP_REDIRECT_URI);
const isOnAuthorize = (url) => url.startsWith("https://moi.ouraring.com/oauth/");
const isOnPortal = (url) => url.startsWith(DEV_PORTAL);

// Returns the signed-in Developer Portal email, or null.
const checkLoginStatus = async () => {
  try {
    return await page.evaluate(`
      (async () => {
        if (!location.href.startsWith(${JSON.stringify(DEV_PORTAL)})) return null;
        const resp = await fetch('/api/auth/session', { credentials: 'include' });
        if (!resp.ok) return null;
        const data = await resp.json().catch(() => null);
        return (data && data.user && data.user.email) || null;
      })()
    `);
  } catch {
    return null;
  }
};

// Reads the OAuth redirect parameters. The code only travels back to the
// connector, never to the log stream.
const readRedirectParams = async () => {
  try {
    return await page.evaluate(`
      (() => {
        if (!location.href.startsWith(${JSON.stringify(APP_REDIRECT_URI)})) return null;
        const params = new URLSearchParams(location.search.slice(1) || location.hash.slice(1));
        return {
          code: params.get('code'),
          state: params.get('state'),
          error: params.get('error'),
        };
      })()
    `);
  } catch {
    return null;
  }
};

// Pre-fills the email on Oura's sign-in page so the user only has to enter
// the one-time code.
const prefillOuraEmail = async (email) => {
  if (!email) return;
  try {
    await page.evaluate(`
      (() => {
        const input = document.querySelector('input#username, input[type="email"]');
        if (!input || input.value) return;
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(input, ${JSON.stringify(email)});
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      })()
    `);
  } catch {
    // Pre-fill is a convenience only.
  }
};

// ── Cached access token (connector browser profile, portal origin) ──

const readCachedToken = async () => {
  try {
    return await page.evaluate(`
      (() => {
        if (!location.href.startsWith(${JSON.stringify(DEV_PORTAL)})) return null;
        try {
          const raw = localStorage.getItem(${JSON.stringify(TOKEN_STORAGE_KEY)});
          return raw ? JSON.parse(raw) : null;
        } catch (e) { return null; }
      })()
    `);
  } catch {
    return null;
  }
};

const writeCachedToken = async (entry) => {
  try {
    await page.evaluate(`
      (() => {
        if (!location.href.startsWith(${JSON.stringify(DEV_PORTAL)})) return false;
        try {
          if (${JSON.stringify(entry)} === null) {
            localStorage.removeItem(${JSON.stringify(TOKEN_STORAGE_KEY)});
          } else {
            localStorage.setItem(${JSON.stringify(TOKEN_STORAGE_KEY)}, ${JSON.stringify(JSON.stringify(entry))});
          }
          return true;
        } catch (e) { return false; }
      })()
    `);
  } catch {
    // Caching is an optimisation; the next run re-authorizes.
  }
};

// A cheap, date-bounded call that proves the token still reads daily data.
const probeToken = async (accessToken) => {
  const today = new Date().toISOString().split("T")[0];
  const resp = await page.httpFetch(
    `${API_BASE}/daily_activity?start_date=${today}&end_date=${today}`,
    {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
      timeout: 15000,
    },
  );
  return {
    status: resp.status,
    detail: resp.ok
      ? null
      : `${String(resp.text || resp.error || "").slice(0, 160)}${resp.headers?.["www-authenticate"] ? ` (www-authenticate: ${resp.headers["www-authenticate"]})` : ""}`,
  };
};

// ── Developer portal API (same-origin proxy, cookie session) ────────

/**
 * Calls the portal's API proxy. Only whitelisted fields cross back into the
 * connector: the client secret stays inside the page.
 */
const portalApi = async (method, path) =>
  page.evaluate(`
    (async () => {
      try {
        const resp = await fetch(${JSON.stringify(`/api/extapi/v2/oauth${path}`)}, {
          method: ${JSON.stringify(method)},
          credentials: 'include',
          headers: { 'Accept': 'application/json' },
        });
        const text = await resp.text();
        let json = null;
        try { json = JSON.parse(text); } catch (e) {}
        const pick = (app) => app && typeof app === 'object' ? {
          clientId: app.client_id,
          name: app.application_name,
          redirectUris: app.redirect_uris || [],
          scopes: app.scopes || [],
          status: app.application_status,
        } : null;
        return {
          ok: resp.ok,
          status: resp.status,
          apps: Array.isArray(json) ? json.map(pick) : null,
          detail: json && json.detail ? String(json.detail).slice(0, 200) : (resp.ok ? null : text.slice(0, 200)),
        };
      } catch (err) {
        return { ok: false, status: 0, detail: err.message || String(err) };
      }
    })()
  `);

// The authorization-code flow needs no implicit grant, so an app with it
// disabled is still usable.
const isUsableApp = (app) =>
  app &&
  app.clientId &&
  app.redirectUris.includes(APP_REDIRECT_URI) &&
  app.scopes.includes(APP_SCOPE);

// Returns { clientId } for a usable app, or { clientId: null } when none
// exists. Throws when the portal API itself fails.
const findApiApplication = async () => {
  const listed = await portalApi("GET", "/applications");
  if (!listed?.ok || !Array.isArray(listed.apps)) {
    throw makeFatalRunError(
      "upstream_error",
      `Could not list Oura API applications (HTTP ${listed?.status || "unknown"}): ${listed?.detail || "no detail"}`,
      "auth",
    );
  }
  const usable =
    listed.apps.find((app) => app?.name === APP_NAME && isUsableApp(app)) ||
    listed.apps.find((app) => isUsableApp(app));
  return { clientId: usable ? usable.clientId : null };
};

/**
 * Opens the portal's "Create New" form, fills everything except the Oura API
 * Agreement checkbox, and waits for the user to accept the agreement and
 * submit. Runs in the headed browser.
 */
const createApiApplicationWithUser = async (contactEmail) => {
  await page.setData("status", "Setting up your personal Oura API application...");
  await safeGoto(APPS_URL, { label: "developer portal" });
  await page.sleep(2000);

  await page.evaluate(`
    (() => {
      const btn = [...document.querySelectorAll('button')].find((b) => /create new/i.test(b.innerText || ''));
      if (btn) btn.click();
    })()
  `);
  await page.sleep(1500);

  const filled = await page.evaluate(`
    (() => {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      const textSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      const setValue = (el, value) => {
        if (!el) return false;
        (el.tagName === 'TEXTAREA' ? textSetter : setter).call(el, value);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('blur', { bubbles: true }));
        return true;
      };
      const byPlaceholder = (p) => [...document.querySelectorAll('input, textarea')].filter((el) => el.placeholder === p);
      const urls = byPlaceholder('Enter a URL');
      const results = [
        setValue(byPlaceholder('Enter a display name')[0], ${JSON.stringify(APP_NAME)}),
        setValue(byPlaceholder('Enter a description')[0], 'Personal connector that exports my own Oura readiness, sleep and activity data to my Vana account.'),
        setValue(byPlaceholder('Enter an email')[0], ${JSON.stringify(contactEmail)}),
        setValue(urls[0], 'https://vana.org'),
        setValue(urls[1], 'https://vana.org/privacy'),
        setValue(urls[2], 'https://vana.org/terms'),
        setValue(byPlaceholder('URI')[0], ${JSON.stringify(APP_REDIRECT_URI)}),
      ];
      // Least privilege: only the Daily scope. Leave the API Agreement box
      // for the user to tick.
      for (const box of document.querySelectorAll('input[type="checkbox"]')) {
        const label = ((box.closest('label') || box.parentElement || {}).innerText || '').trim();
        if (/agree/i.test(label)) continue;
        const wanted = /^daily$/i.test(label);
        if (box.checked !== wanted) box.click();
      }
      return results.every(Boolean);
    })()
  `);
  if (!filled) {
    console.error("[oura] Could not pre-fill every field of the Create New form; the user completes it.");
  }

  await page.setData(
    "status",
    "Tick 'I agree to the Oura API Agreement' and click 'Create Application' in the browser window.",
  );
  const created = await waitFor(async () => {
    if (!isOnPortal(await currentUrl())) return null;
    const { clientId } = await findApiApplication();
    return clientId;
  }, INTERACTION_TIMEOUT_MS, 3000);

  if (!created) {
    throw makeFatalRunError(
      "auth_failed",
      "No Oura API application was created (the Oura API Agreement must be accepted in the browser).",
      "auth",
    );
  }
  return created;
};

// ── OAuth2 authorization-code flow (PKCE + client secret) ───────────

/**
 * Reads the client secret of the user's own API application from the portal
 * API. It is used only for Oura's token endpoint and never logged.
 */
const readClientSecret = async (clientId) =>
  page.evaluate(`
    (async () => {
      try {
        const resp = await fetch('/api/extapi/v2/oauth/applications', { credentials: 'include' });
        if (!resp.ok) return null;
        const apps = await resp.json();
        const app = Array.isArray(apps) ? apps.find((a) => a.client_id === ${JSON.stringify(clientId)}) : null;
        return (app && app.client_secret) || null;
      } catch (e) { return null; }
    })()
  `);

// PKCE verifier + S256 challenge, generated with the page's WebCrypto.
const createPkcePair = async () =>
  page.evaluate(`
    (async () => {
      const b64url = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes)))
        .replace(/\\+/g, '-').replace(/\\//g, '_').replace(/=+$/, '');
      const verifier = b64url(crypto.getRandomValues(new Uint8Array(48)));
      const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
      return { verifier, challenge: b64url(digest) };
    })()
  `);

const buildAuthorizeUrl = (clientId, state, codeChallenge) =>
  `${AUTHORIZE_URL}?response_type=code` +
  `&client_id=${encodeURIComponent(clientId)}` +
  `&redirect_uri=${encodeURIComponent(APP_REDIRECT_URI)}` +
  `&scope=${encodeURIComponent(OAUTH_SCOPE)}` +
  `&state=${encodeURIComponent(state)}` +
  `&code_challenge=${encodeURIComponent(codeChallenge)}` +
  "&code_challenge_method=S256" +
  // Always show the consent screen so an earlier empty grant is not reused.
  "&prompt=consent";

/**
 * Posts a grant to Oura's token endpoint. Returns a cache entry, or throws a
 * fatal auth error. Token values are never logged; only response keys are.
 */
const requestTokens = async (grant, clientId, clientSecret) => {
  const body = new URLSearchParams({ ...grant, client_id: clientId, client_secret: clientSecret });
  const resp = await page.httpFetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
    body: body.toString(),
    timeout: 20000,
  });
  const json = resp.json || {};
  if (!resp.ok || !json.access_token) {
    const reason = json.error_description || json.error || resp.error || `HTTP ${resp.status}`;
    throw makeFatalRunError(
      "auth_failed",
      `Oura token request (${grant.grant_type}) failed: ${String(reason).slice(0, 160)}`,
      "auth",
    );
  }
  console.error(
    `[oura] Token response (${grant.grant_type}): keys=${Object.keys(json).join(",")} ` +
    `scope=${json.scope || "(none)"} expires_in=${json.expires_in}`,
  );
  return {
    accessToken: json.access_token,
    refreshToken: json.refresh_token || grant.refresh_token || null,
    expiresAt: Date.now() + (Number(json.expires_in) || 24 * 3600) * 1000,
    clientId,
    clientSecret,
  };
};

// On Oura's consent screen, makes sure the daily-data box is ticked. The user
// clicks "Allow" themselves: an automated click can land before the page's
// script has bound the scope checkbox and Oura then records an empty grant.
const ensureConsentScopeTicked = async () =>
  page.evaluate(`
    (() => {
      const box = document.querySelector('input[type="checkbox"][name="consent.scope.${OAUTH_SCOPE}"]');
      if (!box) return 'no-consent-form';
      if (!box.checked) box.click();
      return box.checked ? 'ticked' : 'unticked';
    })()
  `);

/**
 * Runs the authorization-code flow in the current (headed) browser: the user
 * signs in and approves, the connector exchanges the code. Returns the token
 * cache entry.
 */
const authorizeWithUser = async (clientId, clientSecret, email) => {
  const state = `vana-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  const pkce = await createPkcePair();
  await page.setData("status", "Sign in to Oura and approve access to your daily data.");
  const opened = await safeGoto(buildAuthorizeUrl(clientId, state, pkce.challenge), {
    attempts: 2,
    label: "Oura authorize",
  });
  if (!opened && !isOnRedirect(await currentUrl())) {
    throw makeFatalRunError("navigation_error", "Could not open the Oura authorization page.", "auth");
  }

  let lastPage = "";
  let consentState = "";
  const reached = await waitFor(async () => {
    const url = await currentUrl();
    if (isOnRedirect(url)) return true;

    const where = describeUrl(url);
    if (where !== lastPage) {
      console.error(`[oura] Authorization waiting on ${where}`);
      lastPage = where;
    }
    if (isOnMoiLogin(url)) {
      await prefillOuraEmail(email);
    } else if (isOnAuthorize(url)) {
      const state = await ensureConsentScopeTicked().catch(() => "");
      if (state && state !== consentState) {
        consentState = state;
        console.error(`[oura] Consent screen: ${state}`);
        if (state === "ticked") {
          await page.setData("status", "Click 'Allow' in the browser window to share your Oura daily data.");
        }
      }
    }
    return null;
  }, INTERACTION_TIMEOUT_MS, 1500);

  if (!reached) {
    throw makeFatalRunError(
      "auth_failed",
      `Oura authorization did not complete (last page: ${lastPage || "unknown"}).`,
      "auth",
    );
  }

  const redirect = await readRedirectParams();
  if (redirect?.error) {
    throw makeFatalRunError("auth_failed", `Oura authorization was declined (${redirect.error}).`, "auth");
  }
  if (!redirect?.code) {
    throw makeFatalRunError("auth_failed", "Oura authorization finished without an authorization code.", "auth");
  }
  if (redirect.state !== state) {
    throw makeFatalRunError("auth_failed", "Oura authorization returned an unexpected state value.", "auth");
  }

  return requestTokens(
    {
      grant_type: "authorization_code",
      code: redirect.code,
      redirect_uri: APP_REDIRECT_URI,
      code_verifier: pkce.verifier,
    },
    clientId,
    clientSecret,
  );
};

// ── Auth orchestration ──────────────────────────────────────────────

// Validates a cache entry, refreshing it when the access token is stale.
// Returns a usable access token, or null when the user must re-authorize.
const tokenFromCache = async (cached) => {
  if (!cached?.accessToken) return null;

  if (Number(cached.expiresAt) > Date.now() + 10 * 60 * 1000) {
    const { status } = await probeToken(cached.accessToken);
    if (status === 200) return cached.accessToken;
    if (status !== 401 && status !== 403) {
      // Oura unreachable or rate limited: let collection report it honestly.
      return cached.accessToken;
    }
  }

  if (cached.refreshToken && cached.clientId && cached.clientSecret) {
    try {
      const refreshed = await requestTokens(
        { grant_type: "refresh_token", refresh_token: cached.refreshToken },
        cached.clientId,
        cached.clientSecret,
      );
      // Refresh tokens are single-use: persist the rotated one immediately.
      await writeCachedToken(refreshed);
      const { status } = await probeToken(refreshed.accessToken);
      if (status !== 401 && status !== 403) return refreshed.accessToken;
    } catch (error) {
      console.error(`[oura] Token refresh failed: ${error?.message || error}`);
    }
  }

  await writeCachedToken(null);
  return null;
};

/**
 * Returns a working API access token.
 *
 * Headless first: a cached access token, or one refreshed with the cached
 * refresh token. Otherwise one headed session covers portal sign-in, app
 * setup and OAuth consent, then the browser returns to headless mode.
 */
const obtainAccessToken = async () => {
  await page.setData("status", "Checking your Oura connection...");
  if (!(await safeGoto(APPS_URL, { label: "developer portal" }))) {
    throw makeFatalRunError(
      "navigation_error",
      "Could not reach the Oura Developer Portal after multiple attempts.",
      "auth",
    );
  }
  await page.sleep(2000);

  const cachedToken = await tokenFromCache(await readCachedToken());
  if (cachedToken) return cachedToken;

  const { headed } = await page.showBrowser(APPS_URL);
  if (!headed) {
    throw makeFatalRunError(
      "auth_failed",
      "Connecting Oura needs a one-time sign-in in a visible browser window.",
      "auth",
    );
  }

  await page.setData("status", "Sign in to Oura in the browser window.");
  let email = await checkLoginStatus();
  if (!email) {
    await page.promptUser(
      "Sign in to the Oura Developer Portal in the browser window to continue.",
      async () => {
        const url = await currentUrl();
        if (url.includes("/signin")) {
          // Starts Oura SSO from the NextAuth sign-in page.
          await page.evaluate(`
            (() => {
              const btn = [...document.querySelectorAll('button')].find((b) => /sign in/i.test(b.innerText || ''));
              if (btn && !window.__vanaSignInClicked) { window.__vanaSignInClicked = true; btn.click(); }
            })()
          `);
          return false;
        }
        if (!isOnPortal(url)) return false;
        return Boolean(await checkLoginStatus());
      },
      3000,
    );
    email = await checkLoginStatus();
  }
  if (!email) {
    throw makeFatalRunError("auth_failed", "Oura sign-in could not be confirmed on the Developer Portal.", "auth");
  }

  let { clientId } = await findApiApplication();
  if (!clientId) {
    clientId = await createApiApplicationWithUser(email);
  }
  const clientSecret = await readClientSecret(clientId);
  if (!clientSecret) {
    throw makeFatalRunError(
      "upstream_error",
      "Could not read the Oura API application credentials from the Developer Portal.",
      "auth",
    );
  }

  const entry = await authorizeWithUser(clientId, clientSecret, email);
  const { status } = await probeToken(entry.accessToken);
  if (status === 401 || status === 403) {
    throw makeFatalRunError(
      "auth_failed",
      `Oura issued a token that cannot read daily summaries (API returned HTTP ${status}).`,
      "auth",
    );
  }

  // Leave the redirect page and cache the tokens on the portal origin before
  // switching back to headless.
  await safeGoto(APPS_URL, { attempts: 2, label: "developer portal" });
  await page.sleep(1500);
  await writeCachedToken(entry);
  await page.goHeadless({ resumeUrl: APPS_URL });

  return entry.accessToken;
};

// ── API V2 collection ───────────────────────────────────────────────

const isoDate = (date) => date.toISOString().split("T")[0];

/**
 * Fetches every document of one usercollection endpoint in the window,
 * following next_token. Returns { ok, data, pages, error, status }.
 */
const fetchCollection = async (accessToken, endpoint, startDate, endDate) => {
  const data = [];
  let nextToken = null;
  let pages = 0;

  do {
    const params = new URLSearchParams({ start_date: startDate, end_date: endDate });
    if (nextToken) params.set("next_token", nextToken);
    const url = `${API_BASE}/${endpoint}?${params.toString()}`;

    let resp = null;
    for (let attempt = 1; attempt <= 4; attempt++) {
      resp = await page.httpFetch(url, {
        headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
        timeout: 30000,
      });
      if (resp.status === 429) {
        const retryAfter = Number(resp.headers?.["retry-after"]) || 5 * attempt;
        await page.setData("status", `Oura rate limit reached; waiting ${retryAfter}s...`);
        await page.sleep(Math.min(retryAfter, 60) * 1000);
        continue;
      }
      if (resp.status === 0 || resp.status >= 500) {
        await page.sleep(1500 * attempt);
        continue;
      }
      break;
    }

    if (!resp?.ok || !resp.json) {
      return {
        ok: false,
        data,
        pages,
        status: resp?.status || 0,
        error: resp?.error || `HTTP ${resp?.status || "unknown"}`,
      };
    }

    data.push(...(Array.isArray(resp.json.data) ? resp.json.data : []));
    nextToken = resp.json.next_token || null;
    pages++;
    if (nextToken) await page.sleep(300);
  } while (nextToken && pages < 50);

  return { ok: true, data, pages, status: 200, error: null };
};

// ── Scope extraction helpers ────────────────────────────────────────

const mapReadiness = (rawReadiness) =>
  rawReadiness.map((d) => ({
    id: d.id,
    day: d.day,
    score: d.score,
    timestamp: d.timestamp,
    temperatureDeviation: d.temperature_deviation,
    temperatureTrendDeviation: d.temperature_trend_deviation,
    contributors: d.contributors || {},
  }));

const mapSleep = (dailySleep, sleepPeriods) => ({
  dailyScores: dailySleep.map((d) => ({
    id: d.id,
    day: d.day,
    score: d.score,
    timestamp: d.timestamp,
    contributors: d.contributors || {},
  })),
  sleepPeriods: sleepPeriods.map((d) => ({
    id: d.id,
    day: d.day,
    type: d.type,
    bedtimeStart: d.bedtime_start,
    bedtimeEnd: d.bedtime_end,
    totalSleepDuration: d.total_sleep_duration,
    timeInBed: d.time_in_bed,
    deepSleepDuration: d.deep_sleep_duration,
    lightSleepDuration: d.light_sleep_duration,
    remSleepDuration: d.rem_sleep_duration,
    awakeTime: d.awake_time,
    efficiency: d.efficiency,
    latency: d.latency,
    averageHeartRate: d.average_heart_rate,
    averageHrv: d.average_hrv,
    lowestHeartRate: d.lowest_heart_rate,
    averageBreath: d.average_breath,
    restlessPeriods: d.restless_periods,
  })),
});

const mapActivity = (rawActivity) =>
  rawActivity.map((d) => ({
    id: d.id,
    day: d.day,
    score: d.score,
    timestamp: d.timestamp,
    activeCalories: d.active_calories,
    totalCalories: d.total_calories,
    steps: d.steps,
    equivalentWalkingDistance: d.equivalent_walking_distance,
    highActivityTime: d.high_activity_time,
    mediumActivityTime: d.medium_activity_time,
    lowActivityTime: d.low_activity_time,
    sedentaryTime: d.sedentary_time,
    restingTime: d.resting_time,
    inactivityAlerts: d.inactivity_alerts,
    contributors: d.contributors || {},
  }));

// ── Main Flow ───────────────────────────────────────────────────────

(async () => {
  let requestedScopes = [...CANONICAL_SCOPES];
  let initError = null;
  try {
    requestedScopes = resolveRequestedScopes();
  } catch (error) {
    initError = error;
  }

  try {
    if (initError) {
      throw initError;
    }

    const errors = [];
    const scopes = {};

    // ── Auth ──
    // Status only: on mobile the first setProgress marks the run as
    // extracting, which must not happen before the owner has signed in.
    await page.setData("status", "Signing in to Oura...");
    const accessToken = await obtainAccessToken();

    // ── Data Collection ──
    const end = new Date();
    end.setDate(end.getDate() + 1); // end_date is exclusive for daily collections
    const start = new Date();
    start.setDate(start.getDate() - LOOKBACK_DAYS);
    const startDate = isoDate(start);
    const endDate = isoDate(end);

    const endpoints = Array.from(
      new Set(requestedScopes.flatMap((scope) => SCOPE_ENDPOINTS[scope])),
    );
    const collections = {};
    for (const endpoint of endpoints) {
      await page.setProgress({
        phase: "collect",
        message: `Downloading Oura ${endpoint.replace(/_/g, " ")}...`,
      });
      collections[endpoint] = await fetchCollection(accessToken, endpoint, startDate, endDate);
      if (collections[endpoint].status === 401) {
        await writeCachedToken(null);
        throw makeFatalRunError(
          "auth_failed",
          "Oura rejected the API access token. Reconnect to authorize again.",
          "collect",
        );
      }
    }

    const allFailed = endpoints.every((endpoint) => !collections[endpoint].ok);
    if (allFailed) {
      const statuses = endpoints.map((e) => collections[e].status).join(", ");
      throw makeFatalRunError(
        collections[endpoints[0]].status === 403 ? "auth_failed" : "upstream_error",
        collections[endpoints[0]].status === 403
          ? "Oura denied access to daily data (HTTP 403). The Oura membership may have expired or the daily scope was not granted."
          : `All Oura API requests failed (HTTP ${statuses}).`,
        "collect",
      );
    }

    // ── Per-scope collection ──
    for (const scope of requestedScopes) {
      const scopeEndpoints = SCOPE_ENDPOINTS[scope];
      const failed = scopeEndpoints.filter((endpoint) => !collections[endpoint].ok);
      const rows = (endpoint) => collections[endpoint].data;

      if (failed.length === scopeEndpoints.length) {
        errors.push(makeConnectorError(
          "upstream_error",
          `Oura API request failed for ${failed.join(", ")} (${failed.map((e) => collections[e].error).join("; ")}).`,
          "omitted",
          { scope, phase: "collect" },
        ));
        continue;
      }

      if (scope === "oura.readiness") {
        scopes[scope] = { days: mapReadiness(rows("daily_readiness")) };
      } else if (scope === "oura.sleep") {
        scopes[scope] = mapSleep(rows("daily_sleep"), rows("sleep"));
      } else if (scope === "oura.activity") {
        scopes[scope] = { days: mapActivity(rows("daily_activity")) };
      }

      if (failed.length > 0) {
        errors.push(makeConnectorError(
          "upstream_error",
          `Oura API request failed for ${failed.join(", ")}; ${scope} data is incomplete.`,
          "degraded",
          { scope, phase: "collect" },
        ));
      }
    }

    // ── Build result ──
    const totalItems =
      (scopes["oura.readiness"]?.days?.length || 0) +
      (scopes["oura.sleep"]?.sleepPeriods?.length || 0) +
      (scopes["oura.activity"]?.days?.length || 0);

    const result = buildResult({
      requestedScopes,
      scopes,
      errors,
      exportSummary: {
        count: totalItems,
        label: "days of Oura data",
        details: {
          readiness: scopes["oura.readiness"]?.days?.length || 0,
          sleepScores: scopes["oura.sleep"]?.dailyScores?.length || 0,
          sleepPeriods: scopes["oura.sleep"]?.sleepPeriods?.length || 0,
          activity: scopes["oura.activity"]?.days?.length || 0,
        },
      },
    });

    await page.setData("result", result);
    await page.setData(
      "status",
      `Complete! ${scopes["oura.readiness"]?.days?.length || 0} readiness, ` +
      `${scopes["oura.sleep"]?.sleepPeriods?.length || 0} sleep periods, ` +
      `${scopes["oura.activity"]?.days?.length || 0} activity days collected.`,
    );

    return result;
  } catch (error) {
    const telemetryError =
      error?.telemetryError ||
      makeConnectorError(
        inferErrorClass(error?.message || String(error)),
        error?.message || String(error),
        "fatal",
        { phase: "collect" },
      );
    const result = buildEmptyResult(requestedScopes, [telemetryError]);
    await page.setData("result", result);
    await page.setData("error", telemetryError.reason);
    return result;
  }
})();
